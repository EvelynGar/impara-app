package mx.impara.app.data

import kotlinx.serialization.Serializable

@Serializable
data class User(
    val id: Long = 0,
    val name: String = "",
    val email: String = "",
    val avatar: String = "",
    val admin: Boolean = false,
)

@Serializable
data class Stats(
    val students: Int = 0,
    val courses: Int = 0,
    val lessons: Int = 0,
)

@Serializable
data class Category(
    val id: Long = 0,
    val name: String = "",
    val count: Int = 0,
    val image: String = "",
    val bundle_id: Long = 0,
    val url: String = "",
)

@Serializable
data class Course(
    val id: Long = 0,
    val title: String = "",
    val thumb: String = "",
    val category: String = "",
    val category_id: Long = 0,
    val url: String = "",
    val product_id: Long = 0,
    val price: Double = 0.0,
    val regular: Double = 0.0,
    val on_sale: Boolean = false,
    val enrolled: Boolean = false,
    val progress: Int? = null,
) {
    val canBuy: Boolean get() = !enrolled && product_id > 0
    val hasDiscount: Boolean get() = on_sale && regular > price && price > 0
}

@Serializable
data class Bundle(
    val id: Long = 0,
    val title: String = "",
    val thumb: String = "",
    val thumbs: List<String> = emptyList(),
    val product_id: Long = 0,
    val price: Double = 0.0,
    val value: Double = 0.0,
    val discount: Int = 0,
    val count: Int = 0,
    val owned: Int = 0,
    val has: Boolean = false,
    val category_id: Long = 0,
    val url: String = "",
)

@Serializable
data class Home(
    val user: User? = null,
    val stats: Stats = Stats(),
    val categories: List<Category> = emptyList(),
    val bundles: List<Bundle> = emptyList(),
    val featured: List<Course> = emptyList(),
    val `continue`: List<Course> = emptyList(),
    val whatsapp: String = "525657769489",
    val site: String = "",
)

@Serializable
data class CoursePage(
    val items: List<Course> = emptyList(),
    val total: Int = 0,
    val pages: Int = 0,
)

@Serializable
data class LessonItem(
    val id: Long = 0,
    val title: String = "",
    val type: String = "lesson",
    val duration: String = "",
)

@Serializable
data class Section(
    val title: String = "",
    val duration: String = "",
    val items: List<LessonItem> = emptyList(),
)

@Serializable
data class CourseDetail(
    val id: Long = 0,
    val title: String = "",
    val thumb: String = "",
    val category: String = "",
    val category_id: Long = 0,
    val url: String = "",
    val product_id: Long = 0,
    val price: Double = 0.0,
    val regular: Double = 0.0,
    val on_sale: Boolean = false,
    val enrolled: Boolean = false,
    val progress: Int? = null,
    val summary: String = "",
    val description: String = "",
    val learn: List<String> = emptyList(),
    val students: Int = 0,
    val lessons: Int = 0,
    val quizzes: Int = 0,
    val duration: String = "",
    val sections: List<Section> = emptyList(),
    val bundles: List<Bundle> = emptyList(),
    val certificate: Boolean = true,
) {
    val canBuy: Boolean get() = !enrolled && product_id > 0
    val hasDiscount: Boolean get() = on_sale && regular > price && price > 0
}

@Serializable
data class BundleDetail(
    val id: Long = 0,
    val title: String = "",
    val thumb: String = "",
    val thumbs: List<String> = emptyList(),
    val product_id: Long = 0,
    val price: Double = 0.0,
    val value: Double = 0.0,
    val discount: Int = 0,
    val count: Int = 0,
    val owned: Int = 0,
    val has: Boolean = false,
    val category_id: Long = 0,
    val url: String = "",
    val courses: List<Course> = emptyList(),
    val lessons: Int = 0,
    val duration: String = "",
    val description: String = "",
)

@Serializable
data class LoginResponse(
    val token: String = "",
    val user: User? = null,
)

@Serializable
data class Me(
    val user: User? = null,
    val courses: List<Course> = emptyList(),
    val completed: Int = 0,
)

@Serializable
data class WebLink(val url: String = "")

@Serializable
data class Notice(
    val id: Long = 0,
    val title: String = "",
    val body: String = "",
    val url: String = "",
    val date: Long = 0,
)

@Serializable
data class NoticeList(val items: List<Notice> = emptyList())

@Serializable
data class ApiError(val code: String = "", val message: String = "")

/** Error con mensaje listo para mostrar al alumno. */
class ApiException(message: String, val status: Int = 0) : Exception(message)

/* ---------- Aula (lecciones dentro de la app) ---------- */

@Serializable
data class LessonVideo(val type: String = "embed", val url: String = "")

@Serializable
data class LearnItem(
    val id: Long = 0,
    val title: String = "",
    val type: String = "lesson",
    val duration: String = "",
    val completed: Boolean = false,
    val web_url: String = "",
    val video: LessonVideo? = null,
    val content: String = "",
    val lesson_type: String = "",
    val pdfs: List<LessonFile> = emptyList(),
    val materials: List<LessonFile> = emptyList(),
) {
    val isPdfLesson: Boolean get() = pdfs.isNotEmpty() && (lesson_type == "pdf-lesson" || video == null || video.url.isBlank())
}

@Serializable
data class LessonFile(val title: String = "", val url: String = "", val mime: String = "") {
    val isPdf: Boolean get() = mime.contains("pdf") || url.substringBefore('?').endsWith(".pdf", ignoreCase = true)
}

@Serializable
data class LearnSection(val title: String = "", val items: List<LearnItem> = emptyList())

@Serializable
data class LearnCourse(val id: Long = 0, val title: String = "", val thumb: String = "")

@Serializable
data class LearnData(
    val course: LearnCourse = LearnCourse(),
    val progress: Int = 0,
    val resume_id: Long = 0,
    val sections: List<LearnSection> = emptyList(),
)

@Serializable
data class CompleteResult(val ok: Boolean = false, val progress: Int = 0)

/* ---------- Administración (solo administradores) ---------- */

@Serializable
data class AdminUser(
    val id: Long = 0,
    val name: String = "",
    val email: String = "",
    val avatar: String = "",
    val since: String = "",
    val courses: Int = 0,
)

@Serializable
data class AdminUsers(val items: List<AdminUser> = emptyList())

@Serializable
data class AdminCourse(
    val id: Long = 0,
    val title: String = "",
    val thumb: String = "",
    val category: String = "",
    val progress: Int = 0,
)

@Serializable
data class AdminOwnedBundle(val id: Long = 0, val title: String = "", val count: Int = 0, val have: Int = 0)

@Serializable
data class AdminUserDetail(
    val user: AdminUser = AdminUser(),
    val courses: List<AdminCourse> = emptyList(),
    val bundles: List<AdminOwnedBundle> = emptyList(),
)

@Serializable
data class AdminCatalogBundle(
    val id: Long = 0,
    val title: String = "",
    val count: Int = 0,
    @kotlinx.serialization.SerialName("private") val isPrivate: Boolean = false,
)

@Serializable
data class AdminCatalog(
    val courses: List<AdminCourse> = emptyList(),
    val bundles: List<AdminCatalogBundle> = emptyList(),
)

@Serializable
data class AdminChange(val ok: Boolean = false, val message: String = "", val courses: List<AdminCourse> = emptyList())
