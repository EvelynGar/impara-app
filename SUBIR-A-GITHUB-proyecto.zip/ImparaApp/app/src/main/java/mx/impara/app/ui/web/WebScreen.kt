package mx.impara.app.ui.web

import android.annotation.SuppressLint
import android.app.DownloadManager
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.view.View
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.URLUtil
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.automirrored.rounded.OpenInNew
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.material.icons.rounded.WifiOff
import mx.impara.app.BuildConfig
import mx.impara.app.ui.components.EmptyState

private const val SITE_HOST = "impara-academy.com.mx"

/** Oculta el encabezado y pie del sitio: la app ya tiene su propia barra. */
private const val APP_CSS = """
#tg-masthead,.md-site-header,#colophon,.site-footer,.elementor-location-footer,.joinchat,.joinchat__button,
[class*="whatsapp-float"],[class*="wa-float"]{display:none!important}
body{padding-top:0!important;margin-top:0!important}
"""

private val INJECT_JS = """
(function(){var id='impara-app-css';if(document.getElementById(id))return;
var s=document.createElement('style');s.id=id;s.textContent=${org.json.JSONObject.quote(APP_CSS)};
(document.head||document.documentElement).appendChild(s);})();
""".trimIndent()

@SuppressLint("SetJavaScriptEnabled")
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun WebScreen(url: String, title: String, onClose: () -> Unit) {
    val context = LocalContext.current
    var progress by remember { mutableIntStateOf(0) }
    var subtitle by remember { mutableStateOf("") }
    var canGoBack by remember { mutableStateOf(false) }
    var failed by remember { mutableStateOf(false) }
    var customView by remember { mutableStateOf<View?>(null) }
    var customCallback by remember { mutableStateOf<WebChromeClient.CustomViewCallback?>(null) }
    var fileCallback by remember { mutableStateOf<ValueCallback<Array<Uri>>?>(null) }

    val fileLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        fileCallback?.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(result.resultCode, result.data))
        fileCallback = null
    }

    val webView = remember {
        WebView(context).apply {
            layoutParams = ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.mediaPlaybackRequiresUserGesture = false
            settings.loadWithOverviewMode = true
            settings.useWideViewPort = true
            settings.setSupportMultipleWindows(false)
            settings.javaScriptCanOpenWindowsAutomatically = true
            settings.userAgentString = settings.userAgentString + " ImparaApp/" + BuildConfig.VERSION_NAME
            CookieManager.getInstance().setAcceptCookie(true)
            CookieManager.getInstance().setAcceptThirdPartyCookies(this, true)

            webViewClient = object : WebViewClient() {
                override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                    val uri = request.url
                    val scheme = uri.scheme?.lowercase() ?: return false
                    val host = uri.host?.lowercase().orEmpty()
                    if (scheme == "http" || scheme == "https") {
                        val external = host == "wa.me" || host.endsWith("whatsapp.com") ||
                            host == "play.google.com" || host.startsWith("maps.")
                        if (external) openExternal(context, uri)
                        return external
                    }
                    if (scheme == "intent") {
                        try {
                            val intent = Intent.parseUri(uri.toString(), Intent.URI_INTENT_SCHEME)
                            context.startActivity(intent)
                        } catch (e: Exception) {
                            val fallback = runCatching {
                                Intent.parseUri(uri.toString(), Intent.URI_INTENT_SCHEME).getStringExtra("browser_fallback_url")
                            }.getOrNull()
                            if (fallback != null) view.loadUrl(fallback)
                        }
                        return true
                    }
                    openExternal(context, uri) // mailto:, tel:, whatsapp:, etc.
                    return true
                }

                override fun onPageStarted(view: WebView, url: String?, favicon: Bitmap?) {
                    failed = false
                    if (Uri.parse(url ?: "").host?.endsWith(SITE_HOST) == true) view.evaluateJavascript(INJECT_JS, null)
                }

                override fun onPageFinished(view: WebView, url: String?) {
                    canGoBack = view.canGoBack()
                    val host = Uri.parse(url ?: "").host.orEmpty()
                    subtitle = if (host.endsWith(SITE_HOST)) "" else host
                    if (host.endsWith(SITE_HOST)) view.evaluateJavascript(INJECT_JS, null)
                    CookieManager.getInstance().flush()
                }

                override fun doUpdateVisitedHistory(view: WebView, url: String?, isReload: Boolean) {
                    canGoBack = view.canGoBack()
                }

                override fun onReceivedError(view: WebView, request: WebResourceRequest, error: WebResourceError) {
                    if (request.isForMainFrame) failed = true
                }
            }

            webChromeClient = object : WebChromeClient() {
                override fun onProgressChanged(view: WebView, newProgress: Int) {
                    progress = newProgress
                }

                override fun onShowCustomView(view: View, callback: CustomViewCallback) {
                    customView = view
                    customCallback = callback
                }

                override fun onHideCustomView() {
                    customView = null
                    customCallback = null
                }

                override fun onShowFileChooser(
                    webView: WebView,
                    filePathCallback: ValueCallback<Array<Uri>>,
                    fileChooserParams: FileChooserParams,
                ): Boolean {
                    fileCallback?.onReceiveValue(null)
                    fileCallback = filePathCallback
                    return try {
                        fileLauncher.launch(fileChooserParams.createIntent())
                        true
                    } catch (e: Exception) {
                        fileCallback = null
                        false
                    }
                }
            }

            setDownloadListener { dlUrl, userAgent, contentDisposition, mimeType, _ ->
                download(context, dlUrl, userAgent, contentDisposition, mimeType)
            }

            loadUrl(url)
        }
    }

    DisposableEffect(webView) {
        onDispose {
            webView.stopLoading()
            webView.destroy()
        }
    }

    BackHandler {
        when {
            customView != null -> {
                customCallback?.onCustomViewHidden()
                customView = null
            }
            webView.canGoBack() -> webView.goBack()
            else -> onClose()
        }
    }

    Scaffold(
        topBar = {
            Column {
                TopAppBar(
                    title = {
                        Column {
                            Text(title, maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.titleMedium)
                            Text(
                                subtitle.ifBlank { "impara-academy.com.mx" },
                                maxLines = 1,
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                    },
                    navigationIcon = {
                        IconButton(onClick = onClose) { Icon(Icons.Rounded.Close, "Cerrar") }
                    },
                    actions = {
                        if (canGoBack) {
                            IconButton(onClick = { webView.goBack() }) { Icon(Icons.AutoMirrored.Rounded.ArrowBack, "Página anterior") }
                        }
                        IconButton(onClick = { openExternal(context, Uri.parse(webView.url ?: url)) }) {
                            Icon(Icons.AutoMirrored.Rounded.OpenInNew, "Abrir en el navegador")
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLow),
                )
                if (progress in 1..99) {
                    LinearProgressIndicator(progress = { progress / 100f }, modifier = Modifier.fillMaxWidth())
                }
            }
        },
    ) { padding ->
        Box(Modifier.fillMaxSize().padding(padding)) {
            AndroidView(factory = { webView }, modifier = Modifier.fillMaxSize())
            if (failed) {
                Box(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.surface), contentAlignment = Alignment.Center) {
                    EmptyState(
                        Icons.Rounded.WifiOff,
                        "No se pudo cargar la página",
                        "Revisa tu conexión a internet e intenta de nuevo.",
                        action = "Reintentar",
                        onAction = {
                            failed = false
                            webView.reload()
                        },
                    )
                }
            }
        }
    }

    // Video en pantalla completa (lecciones).
    customView?.let { v ->
        Box(Modifier.fillMaxSize().background(Color.Black)) {
            AndroidView(
                factory = {
                    FrameLayout(it).apply {
                        (v.parent as? ViewGroup)?.removeView(v)
                        addView(v, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))
                    }
                },
                modifier = Modifier.fillMaxSize(),
            )
        }
    }
}

private fun openExternal(context: Context, uri: Uri) {
    try {
        context.startActivity(Intent(Intent.ACTION_VIEW, uri).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    } catch (e: Exception) {
        Toast.makeText(context, "No hay una app para abrir este enlace.", Toast.LENGTH_SHORT).show()
    }
}

/** Descarga constancias, diplomas o materiales con la sesión del alumno. */
private fun download(context: Context, url: String, userAgent: String?, contentDisposition: String?, mimeType: String?) {
    try {
        val name = URLUtil.guessFileName(url, contentDisposition, mimeType)
        val request = DownloadManager.Request(Uri.parse(url)).apply {
            setMimeType(mimeType)
            CookieManager.getInstance().getCookie(url)?.let { addRequestHeader("Cookie", it) }
            if (userAgent != null) addRequestHeader("User-Agent", userAgent)
            setTitle(name)
            setDescription("Impara Academy")
            setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, name)
            } else {
                setDestinationInExternalFilesDir(context, Environment.DIRECTORY_DOWNLOADS, name)
            }
        }
        (context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager).enqueue(request)
        Toast.makeText(context, "Descargando $name…", Toast.LENGTH_SHORT).show()
    } catch (e: Exception) {
        openExternal(context, Uri.parse(url))
    }
}
