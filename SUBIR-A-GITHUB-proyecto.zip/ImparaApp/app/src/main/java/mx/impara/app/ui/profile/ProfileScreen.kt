package mx.impara.app.ui.profile

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.Logout
import androidx.compose.material.icons.automirrored.rounded.OpenInNew
import androidx.compose.material.icons.rounded.AccountCircle
import androidx.compose.material.icons.rounded.Language
import androidx.compose.material.icons.rounded.NotificationsActive
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material.icons.rounded.Receipt
import androidx.compose.material.icons.rounded.SupportAgent
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.ListItem
import androidx.compose.material3.ListItemDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.AsyncImage
import kotlinx.coroutines.launch
import mx.impara.app.BuildConfig
import mx.impara.app.data.Repository
import mx.impara.app.data.WebTarget
import mx.impara.app.ui.LocalActions
import mx.impara.app.ui.LocalRepository
import mx.impara.app.ui.components.MainBottomBar
import mx.impara.app.ui.components.Tab
import mx.impara.app.ui.theme.ImparaPurple
import mx.impara.app.ui.theme.ImparaPurpleDeep

@Composable
fun ProfileScreen() {
    val repo = LocalRepository.current
    val actions = LocalActions.current
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val session by repo.session.collectAsStateWithLifecycle()
    val notify by repo.store.notificationsEnabled.collectAsStateWithLifecycle(initialValue = true)
    var confirmLogout by remember { mutableStateOf(false) }
    val user = session?.user

    fun openExternal(url: String) {
        runCatching { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) }
    }

    Scaffold(bottomBar = { MainBottomBar(Tab.Profile, actions::tab) }) { padding ->
        Column(
            Modifier
                .fillMaxSize()
                .padding(bottom = padding.calculateBottomPadding())
                .verticalScroll(rememberScrollState()),
        ) {
            // Encabezado
            Box(
                Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(bottomStart = 28.dp, bottomEnd = 28.dp))
                    .background(Brush.linearGradient(listOf(ImparaPurple, ImparaPurpleDeep)))
                    .statusBarsPadding()
                    .padding(24.dp),
            ) {
                Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                    Box(
                        Modifier.size(88.dp).clip(CircleShape).background(Color.White.copy(alpha = .18f)),
                        contentAlignment = Alignment.Center,
                    ) {
                        if (user != null && user.avatar.isNotBlank()) {
                            AsyncImage(user.avatar, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                        } else {
                            Icon(Icons.Rounded.Person, null, tint = Color.White, modifier = Modifier.size(48.dp))
                        }
                    }
                    Spacer(Modifier.height(12.dp))
                    if (user != null) {
                        Text(user.name, style = MaterialTheme.typography.titleLarge, color = Color.White, textAlign = TextAlign.Center)
                        Text(user.email, style = MaterialTheme.typography.bodyMedium, color = Color.White.copy(alpha = .8f))
                    } else {
                        Text("Bienvenido a Impara", style = MaterialTheme.typography.titleLarge, color = Color.White)
                        Text(
                            "Inicia sesión para ver tus cursos, tu avance y tus compras.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = Color.White.copy(alpha = .85f),
                            textAlign = TextAlign.Center,
                        )
                        Spacer(Modifier.height(16.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            Button(
                                onClick = actions::login,
                                colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = ImparaPurple),
                            ) { Text("Iniciar sesión") }
                        }
                    }
                }
            }

            Spacer(Modifier.height(12.dp))
            Group("Mi cuenta") {
                if (user != null) {
                    Option(Icons.Rounded.AccountCircle, "Mi cuenta en la web", "Datos personales, constancias y certificados") {
                        actions.web(WebTarget(title = "Mi cuenta", url = Repository.SITE + "account/"))
                    }
                    Option(Icons.Rounded.Receipt, "Mis compras", "Pedidos y comprobantes de pago") {
                        actions.web(WebTarget(title = "Mis compras", url = Repository.SITE + "my-account-2/orders/"))
                    }
                }
                ListItem(
                    headlineContent = { Text("Notificaciones") },
                    supportingContent = { Text("Nuevos cursos y promociones") },
                    leadingContent = { Icon(Icons.Rounded.NotificationsActive, null, tint = MaterialTheme.colorScheme.primary) },
                    trailingContent = {
                        Switch(checked = notify, onCheckedChange = { v -> scope.launch { repo.store.setNotificationsEnabled(v) } })
                    },
                    colors = ListItemDefaults.colors(containerColor = Color.Transparent),
                )
            }

            Group("Ayuda") {
                Option(Icons.Rounded.SupportAgent, "Soporte por WhatsApp", "+52 56 5776 9489", external = true) {
                    openExternal("https://wa.me/525657769489?text=" + Uri.encode("Hola, necesito ayuda con la app de Impara Academy."))
                }
                Option(Icons.Rounded.Language, "Visitar impara-academy.com.mx", null, external = true) {
                    openExternal(Repository.SITE)
                }
            }

            if (user != null) {
                Spacer(Modifier.height(8.dp))
                OutlinedButton(
                    onClick = { confirmLogout = true },
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp).height(48.dp),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.error),
                ) {
                    Icon(Icons.AutoMirrored.Rounded.Logout, null, Modifier.size(18.dp))
                    Spacer(Modifier.width(8.dp))
                    Text("Cerrar sesión")
                }
            }

            Text(
                "Impara Academy · versión ${BuildConfig.VERSION_NAME}",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth().padding(24.dp),
            )
        }
    }

    if (confirmLogout) {
        AlertDialog(
            onDismissRequest = { confirmLogout = false },
            title = { Text("¿Cerrar sesión?") },
            text = { Text("Podrás volver a entrar cuando quieras con tu correo y contraseña.") },
            confirmButton = {
                TextButton(onClick = {
                    confirmLogout = false
                    scope.launch { repo.logout() }
                }) { Text("Cerrar sesión") }
            },
            dismissButton = { TextButton(onClick = { confirmLogout = false }) { Text("Cancelar") } },
        )
    }
}

@Composable
private fun Group(title: String, content: @Composable () -> Unit) {
    Text(
        title,
        style = MaterialTheme.typography.titleSmall,
        color = MaterialTheme.colorScheme.primary,
        modifier = Modifier.padding(start = 20.dp, top = 16.dp, bottom = 6.dp),
    )
    Surface(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
        shape = MaterialTheme.shapes.large,
        color = MaterialTheme.colorScheme.surfaceContainerLow,
    ) {
        Column { content() }
    }
}

@Composable
private fun Option(icon: ImageVector, title: String, subtitle: String?, external: Boolean = false, onClick: () -> Unit) {
    ListItem(
        headlineContent = { Text(title) },
        supportingContent = if (subtitle != null) {
            { Text(subtitle) }
        } else {
            null
        },
        leadingContent = { Icon(icon, null, tint = MaterialTheme.colorScheme.primary) },
        trailingContent = if (external) {
            { Icon(Icons.AutoMirrored.Rounded.OpenInNew, null, Modifier.size(18.dp)) }
        } else {
            null
        },
        colors = ListItemDefaults.colors(containerColor = Color.Transparent),
        modifier = Modifier.clickable(onClick = onClick),
    )
    HorizontalDivider(Modifier.padding(start = 56.dp), color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = .5f))
}
