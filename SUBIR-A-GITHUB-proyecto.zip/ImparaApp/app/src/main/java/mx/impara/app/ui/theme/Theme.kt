package mx.impara.app.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import mx.impara.app.R

// Colores de marca Impara
val ImparaPurple = Color(0xFF642C7C)
val ImparaPurpleDeep = Color(0xFF2A0F40)
val ImparaOrange = Color(0xFFFF6B1A)
val SuccessGreen = Color(0xFF1E8E4F)

private val Light = lightColorScheme(
    primary = ImparaPurple,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFF0DBFF),
    onPrimaryContainer = Color(0xFF2C0049),
    secondary = Color(0xFF675A6E),
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFEFDDF5),
    onSecondaryContainer = Color(0xFF221728),
    tertiary = Color(0xFFB4470B),
    onTertiary = Color.White,
    tertiaryContainer = Color(0xFFFFDBCB),
    onTertiaryContainer = Color(0xFF370E00),
    background = Color(0xFFFFF7FD),
    onBackground = Color(0xFF1E1A20),
    surface = Color(0xFFFFF7FD),
    onSurface = Color(0xFF1E1A20),
    surfaceVariant = Color(0xFFEBDFEA),
    onSurfaceVariant = Color(0xFF4C444F),
    surfaceContainerLowest = Color.White,
    surfaceContainerLow = Color(0xFFFAF1F9),
    surfaceContainer = Color(0xFFF4EBF3),
    surfaceContainerHigh = Color(0xFFEEE5ED),
    surfaceContainerHighest = Color(0xFFE9E0E8),
    outline = Color(0xFF7D7480),
    outlineVariant = Color(0xFFCEC3D0),
    error = Color(0xFFBA1A1A),
)

private val Dark = darkColorScheme(
    primary = Color(0xFFDDB8FF),
    onPrimary = Color(0xFF461A67),
    primaryContainer = Color(0xFF642C7C),
    onPrimaryContainer = Color(0xFFF0DBFF),
    secondary = Color(0xFFD2C1D9),
    onSecondary = Color(0xFF372C3E),
    secondaryContainer = Color(0xFF4E4256),
    onSecondaryContainer = Color(0xFFEFDDF5),
    tertiary = Color(0xFFFFB693),
    onTertiary = Color(0xFF5A1C00),
    tertiaryContainer = Color(0xFF8A3300),
    onTertiaryContainer = Color(0xFFFFDBCB),
    background = Color(0xFF151217),
    onBackground = Color(0xFFE9E0E8),
    surface = Color(0xFF151217),
    onSurface = Color(0xFFE9E0E8),
    surfaceVariant = Color(0xFF4C444F),
    onSurfaceVariant = Color(0xFFCEC3D0),
    surfaceContainerLowest = Color(0xFF100D12),
    surfaceContainerLow = Color(0xFF1E1A20),
    surfaceContainer = Color(0xFF221E24),
    surfaceContainerHigh = Color(0xFF2C282E),
    surfaceContainerHighest = Color(0xFF373339),
    outline = Color(0xFF978E99),
    outlineVariant = Color(0xFF4C444F),
)

val Poppins = FontFamily(
    Font(R.font.poppins_regular, FontWeight.Normal),
    Font(R.font.poppins_medium, FontWeight.Medium),
    Font(R.font.poppins_medium, FontWeight.SemiBold),
    Font(R.font.poppins_bold, FontWeight.Bold),
)

private val base = Typography()

private fun TextStyle.p(weight: FontWeight? = null) =
    copy(fontFamily = Poppins, fontWeight = weight ?: fontWeight)

val ImparaTypography = Typography(
    displayLarge = base.displayLarge.p(FontWeight.Bold),
    displayMedium = base.displayMedium.p(FontWeight.Bold),
    displaySmall = base.displaySmall.p(FontWeight.Bold),
    headlineLarge = base.headlineLarge.p(FontWeight.Bold),
    headlineMedium = base.headlineMedium.p(FontWeight.Bold),
    headlineSmall = base.headlineSmall.p(FontWeight.SemiBold).copy(fontSize = 22.sp),
    titleLarge = base.titleLarge.p(FontWeight.SemiBold),
    titleMedium = base.titleMedium.p(FontWeight.SemiBold),
    titleSmall = base.titleSmall.p(FontWeight.Medium),
    bodyLarge = base.bodyLarge.p(),
    bodyMedium = base.bodyMedium.p(),
    bodySmall = base.bodySmall.p(),
    labelLarge = base.labelLarge.p(FontWeight.Medium),
    labelMedium = base.labelMedium.p(FontWeight.Medium),
    labelSmall = base.labelSmall.p(FontWeight.Medium),
)

val ImparaShapes = Shapes(
    extraSmall = RoundedCornerShape(6.dp),
    small = RoundedCornerShape(10.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(24.dp),
    extraLarge = RoundedCornerShape(32.dp),
)

@Composable
fun ImparaTheme(darkTheme: Boolean = isSystemInDarkTheme(), content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = if (darkTheme) Dark else Light,
        typography = ImparaTypography,
        shapes = ImparaShapes,
        content = content,
    )
}
