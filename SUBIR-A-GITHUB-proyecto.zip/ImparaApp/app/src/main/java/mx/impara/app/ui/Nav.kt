package mx.impara.app.ui

import android.net.Uri
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.core.tween
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import kotlinx.coroutines.launch
import mx.impara.app.data.Repository
import mx.impara.app.data.WebTarget
import mx.impara.app.ui.bundle.BundleScreen
import mx.impara.app.ui.components.Tab
import mx.impara.app.ui.course.CourseScreen
import mx.impara.app.ui.explore.ExploreScreen
import mx.impara.app.ui.home.HomeScreen
import mx.impara.app.ui.login.LoginScreen
import mx.impara.app.ui.mine.MyCoursesScreen
import mx.impara.app.ui.profile.ProfileScreen
import mx.impara.app.ui.web.WebScreen

val LocalRepository = staticCompositionLocalOf<Repository> { error("Repository no disponible") }
val LocalActions = staticCompositionLocalOf<AppActions> { error("Acciones no disponibles") }

/** Acciones de navegación compartidas por todas las pantallas. */
class AppActions(
    private val nav: NavHostController,
    private val open: (WebTarget) -> Unit,
) {
    fun tab(tab: Tab) {
        nav.navigate(tab.route) {
            popUpTo(nav.graph.findStartDestination().id) { saveState = true }
            launchSingleTop = true
            restoreState = true
        }
    }

    fun course(id: Long) = nav.navigate("course/$id")
    fun bundle(id: Long) = nav.navigate("bundle/$id")
    fun explore(categoryId: Long = 0, search: Boolean = false) {
        nav.navigate("explore?cat=$categoryId&search=$search") {
            popUpTo(nav.graph.findStartDestination().id) { saveState = false }
            launchSingleTop = true
        }
    }
    fun login() = nav.navigate("login") { launchSingleTop = true }
    fun back() { nav.popBackStack() }

    /** Abre una página del sitio dentro de la app (con la sesión del alumno si la tiene). */
    fun web(target: WebTarget) = open(target)
    fun web(title: String, url: String) = open(WebTarget(title = title, url = url))
}

@Composable
fun AppNav(repo: Repository, pendingUrl: Pair<String, String>?, onPendingHandled: () -> Unit) {
    val nav = rememberNavController()
    val scope = rememberCoroutineScope()
    var opening by remember { mutableStateOf(false) }
    val snackbar = remember { SnackbarHostState() }

    val actions = remember(nav) {
        AppActions(nav) { target ->
            if (!opening) {
                opening = true
                scope.launch {
                    val url = repo.resolveWebUrl(target)
                    opening = false
                    nav.navigate("web?url=${Uri.encode(url)}&title=${Uri.encode(target.title)}")
                }
            }
        }
    }

    // Enlace recibido desde una notificación o un link del sitio.
    LaunchedEffect(pendingUrl) {
        val p = pendingUrl ?: return@LaunchedEffect
        actions.web(p.second.ifBlank { "Impara Academy" }, p.first)
        onPendingHandled()
    }

    CompositionLocalProvider(LocalRepository provides repo, LocalActions provides actions) {
        Box(Modifier.fillMaxSize()) {
            NavHost(
                navController = nav,
                startDestination = Tab.Home.route,
                enterTransition = { fadeIn(tween(220)) },
                exitTransition = { fadeOut(tween(160)) },
                popEnterTransition = { fadeIn(tween(220)) },
                popExitTransition = { fadeOut(tween(160)) },
            ) {
                composable(Tab.Home.route) { HomeScreen() }
                composable(
                    "explore?cat={cat}&search={search}",
                    arguments = listOf(
                        navArgument("cat") { type = NavType.LongType; defaultValue = 0L },
                        navArgument("search") { type = NavType.BoolType; defaultValue = false },
                    ),
                ) { entry ->
                    ExploreScreen(
                        initialCategory = entry.arguments?.getLong("cat") ?: 0L,
                        focusSearch = entry.arguments?.getBoolean("search") ?: false,
                    )
                }
                composable(Tab.Mine.route) { MyCoursesScreen() }
                composable(Tab.Profile.route) { ProfileScreen() }
                composable(
                    "course/{id}",
                    arguments = listOf(navArgument("id") { type = NavType.LongType }),
                    enterTransition = { slideInHorizontally(tween(260)) { it / 4 } + fadeIn(tween(260)) },
                    popExitTransition = { slideOutHorizontally(tween(200)) { it / 4 } + fadeOut(tween(200)) },
                ) { entry -> CourseScreen(entry.arguments?.getLong("id") ?: 0L) }
                composable(
                    "bundle/{id}",
                    arguments = listOf(navArgument("id") { type = NavType.LongType }),
                    enterTransition = { slideInHorizontally(tween(260)) { it / 4 } + fadeIn(tween(260)) },
                    popExitTransition = { slideOutHorizontally(tween(200)) { it / 4 } + fadeOut(tween(200)) },
                ) { entry -> BundleScreen(entry.arguments?.getLong("id") ?: 0L) }
                composable("login") { LoginScreen() }
                composable(
                    "web?url={url}&title={title}",
                    arguments = listOf(
                        navArgument("url") { type = NavType.StringType; defaultValue = Repository.SITE },
                        navArgument("title") { type = NavType.StringType; defaultValue = "Impara Academy" },
                    ),
                ) { entry ->
                    WebScreen(
                        url = entry.arguments?.getString("url") ?: Repository.SITE,
                        title = entry.arguments?.getString("title") ?: "Impara Academy",
                        onClose = {
                            repo.invalidate()
                            nav.popBackStack()
                        },
                    )
                }
            }
            if (opening) {
                LinearProgressIndicator(
                    Modifier.fillMaxWidth().statusBarsPadding().align(Alignment.TopCenter),
                    color = MaterialTheme.colorScheme.tertiary,
                )
            }
            SnackbarHost(snackbar, Modifier.align(Alignment.BottomCenter))
        }
    }
}
