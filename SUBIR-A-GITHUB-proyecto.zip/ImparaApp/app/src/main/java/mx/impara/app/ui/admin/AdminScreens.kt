package mx.impara.app.ui.admin

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.AdminPanelSettings
import androidx.compose.material.icons.rounded.Clear
import androidx.compose.material.icons.rounded.DeleteOutline
import androidx.compose.material.icons.rounded.Inventory2
import androidx.compose.material.icons.rounded.PersonAdd
import androidx.compose.material.icons.rounded.PersonSearch
import androidx.compose.material.icons.rounded.School
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.ListItem
import androidx.compose.material3.ListItemDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import coil.compose.AsyncImage
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import mx.impara.app.data.AdminCatalog
import mx.impara.app.data.AdminCourse
import mx.impara.app.data.AdminUser
import mx.impara.app.data.AdminUserDetail
import mx.impara.app.data.ApiException
import mx.impara.app.data.Repository
import mx.impara.app.ui.LocalActions
import mx.impara.app.ui.LocalRepository
import mx.impara.app.ui.components.EmptyState
import mx.impara.app.ui.components.ErrorState
import mx.impara.app.ui.components.MainBottomBar
import mx.impara.app.ui.components.NetImage
import mx.impara.app.ui.components.Skeleton
import mx.impara.app.ui.components.Tab
import mx.impara.app.ui.components.UiState
import mx.impara.app.ui.theme.SuccessGreen

/* ================================================================
 * Buscar alumnos
 * ================================================================ */

data class UsersState(
    val query: String = "",
    val loading: Boolean = true,
    val items: List<AdminUser> = emptyList(),
    val error: String? = null,
)

class AdminUsersViewModel(private val repo: Repository) : ViewModel() {
    private val _state = MutableStateFlow(UsersState())
    val state = _state.asStateFlow()
    private var job: Job? = null

    init {
        search("")
    }

    fun search(q: String, debounce: Boolean = false) {
        _state.update { it.copy(query = q) }
        job?.cancel()
        job = viewModelScope.launch {
            if (debounce) delay(400)
            _state.update { it.copy(loading = true, error = null) }
            try {
                val res = repo.adminUsers(q.trim())
                _state.update { it.copy(loading = false, items = res.items) }
            } catch (e: ApiException) {
                _state.update { it.copy(loading = false, error = e.message) }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminScreen() {
    val repo = LocalRepository.current
    val actions = LocalActions.current
    val session by repo.session.collectAsStateWithLifecycle()
    val focus = LocalFocusManager.current

    Scaffold(
        topBar = { TopAppBar(title = { Text("Administración") }) },
        bottomBar = { MainBottomBar(Tab.Admin, actions::tab) },
    ) { padding ->
        Box(Modifier.fillMaxSize().padding(padding)) {
            if (session?.user?.admin != true) {
                EmptyState(
                    Icons.Rounded.AdminPanelSettings,
                    "Solo administradores",
                    "Inicia sesión con una cuenta de administrador para matricular alumnos.",
                )
                return@Box
            }
            val vm: AdminUsersViewModel = viewModel { AdminUsersViewModel(repo) }
            val s by vm.state.collectAsStateWithLifecycle()
            Column(Modifier.fillMaxSize()) {
                Text(
                    "Busca un alumno para matricularlo en un curso o paquete, o darlo de baja.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(horizontal = 16.dp),
                )
                OutlinedTextField(
                    value = s.query,
                    onValueChange = { vm.search(it, debounce = true) },
                    modifier = Modifier.fillMaxWidth().padding(16.dp),
                    placeholder = { Text("Nombre, correo o usuario") },
                    leadingIcon = { Icon(Icons.Rounded.Search, null) },
                    trailingIcon = {
                        if (s.query.isNotEmpty()) IconButton(onClick = { vm.search("") }) { Icon(Icons.Rounded.Clear, "Borrar") }
                    },
                    singleLine = true,
                    shape = CircleShape,
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                    keyboardActions = KeyboardActions(onSearch = { focus.clearFocus() }),
                    colors = OutlinedTextFieldDefaults.colors(
                        unfocusedContainerColor = MaterialTheme.colorScheme.surfaceContainerHigh,
                        focusedContainerColor = MaterialTheme.colorScheme.surfaceContainerHigh,
                        unfocusedBorderColor = MaterialTheme.colorScheme.surfaceContainerHigh,
                    ),
                )
                if (s.loading) LinearProgressIndicator(Modifier.fillMaxWidth())
                when {
                    s.error != null && s.items.isEmpty() -> ErrorState(s.error ?: "", { vm.search(s.query) })
                    !s.loading && s.items.isEmpty() -> EmptyState(
                        Icons.Rounded.PersonSearch,
                        "Sin resultados",
                        "No encontramos alumnos con “${s.query}”. Prueba con su correo.",
                    )
                    else -> LazyColumn(contentPadding = PaddingValues(bottom = 24.dp)) {
                        item {
                            Text(
                                if (s.query.isBlank()) "Alumnos recientes" else "Resultados",
                                style = MaterialTheme.typography.titleSmall,
                                color = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp),
                            )
                        }
                        items(s.items, key = { it.id }) { u ->
                            ListItem(
                                headlineContent = { Text(u.name, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                                supportingContent = { Text(u.email, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                                leadingContent = { Avatar(u.avatar, 44) },
                                trailingContent = {
                                    Surface(shape = CircleShape, color = MaterialTheme.colorScheme.primaryContainer) {
                                        Text(
                                            "${u.courses} cursos",
                                            style = MaterialTheme.typography.labelMedium,
                                            color = MaterialTheme.colorScheme.onPrimaryContainer,
                                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                                        )
                                    }
                                },
                                colors = ListItemDefaults.colors(containerColor = Color.Transparent),
                                modifier = Modifier.padding(horizontal = 8.dp).clip(MaterialTheme.shapes.medium)
                                    .clickable { actions.adminUser(u.id) },
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun Avatar(url: String, size: Int) {
    Box(
        Modifier.size(size.dp).clip(CircleShape).background(MaterialTheme.colorScheme.primaryContainer),
        contentAlignment = Alignment.Center,
    ) {
        if (url.isNotBlank()) {
            AsyncImage(url, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        }
    }
}

/* ================================================================
 * Ficha del alumno: cursos, paquetes, matricular y dar de baja
 * ================================================================ */

/** Acción pendiente de confirmar. */
data class PendingChange(val enroll: Boolean, val title: String, val courseId: Long = 0, val bundleId: Long = 0)

class AdminUserViewModel(private val repo: Repository, private val userId: Long) : ViewModel() {
    private val _state = MutableStateFlow<UiState<AdminUserDetail>>(UiState.Loading)
    val state = _state.asStateFlow()
    private val _catalog = MutableStateFlow<AdminCatalog?>(null)
    val catalog = _catalog.asStateFlow()
    private val _busy = MutableStateFlow(false)
    val busy = _busy.asStateFlow()
    private val _message = MutableStateFlow<String?>(null)
    val message = _message.asStateFlow()

    init {
        load()
        viewModelScope.launch { runCatching { repo.adminCatalog() }.getOrNull()?.let { _catalog.value = it } }
    }

    fun load() {
        viewModelScope.launch {
            if (_state.value !is UiState.Ready) _state.value = UiState.Loading
            _state.value = try {
                UiState.Ready(repo.adminUser(userId))
            } catch (e: ApiException) {
                UiState.Error(e.message ?: "")
            }
        }
    }

    fun apply(change: PendingChange) {
        viewModelScope.launch {
            _busy.value = true
            try {
                val res = repo.adminChange(change.enroll, userId, change.courseId, change.bundleId)
                _message.value = res.message.ifBlank { if (change.enroll) "Listo: alumno inscrito." else "Listo: alumno dado de baja." }
                _state.value = UiState.Ready(repo.adminUser(userId))
            } catch (e: ApiException) {
                _message.value = e.message
            } finally {
                _busy.value = false
            }
        }
    }

    fun messageShown() {
        _message.value = null
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminUserScreen(userId: Long) {
    val repo = LocalRepository.current
    val actions = LocalActions.current
    val vm: AdminUserViewModel = viewModel(key = "admin-user-$userId") { AdminUserViewModel(repo, userId) }
    val state by vm.state.collectAsStateWithLifecycle()
    val catalog by vm.catalog.collectAsStateWithLifecycle()
    val busy by vm.busy.collectAsStateWithLifecycle()
    val message by vm.message.collectAsStateWithLifecycle()
    val snackbar = remember { SnackbarHostState() }
    var pending by remember { mutableStateOf<PendingChange?>(null) }
    var showSheet by remember { mutableStateOf(false) }

    LaunchedEffect(message) {
        message?.let {
            snackbar.showSnackbar(it)
            vm.messageShown()
        }
    }

    val detail = (state as? UiState.Ready)?.data

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(detail?.user?.name ?: "Alumno", maxLines = 1, overflow = TextOverflow.Ellipsis) },
                navigationIcon = { IconButton(onClick = { actions.back() }) { Icon(Icons.AutoMirrored.Rounded.ArrowBack, "Regresar") } },
            )
        },
        floatingActionButton = {
            if (detail != null) {
                ExtendedFloatingActionButton(
                    onClick = { showSheet = true },
                    icon = { Icon(Icons.Rounded.PersonAdd, null) },
                    text = { Text("Matricular") },
                )
            }
        },
        snackbarHost = { SnackbarHost(snackbar) },
    ) { padding ->
        Box(Modifier.fillMaxSize().padding(padding)) {
            when (val s = state) {
                UiState.Loading -> Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    repeat(5) { Skeleton(Modifier.fillMaxWidth().height(72.dp), MaterialTheme.shapes.medium) }
                }
                is UiState.Error -> ErrorState(s.message, vm::load)
                is UiState.Ready -> UserDetail(
                    d = s.data,
                    onRemoveCourse = { c -> pending = PendingChange(false, c.title, courseId = c.id) },
                    onRemoveBundle = { id, title -> pending = PendingChange(false, title, bundleId = id) },
                )
            }
            if (busy) LinearProgressIndicator(Modifier.fillMaxWidth().align(Alignment.TopCenter))
        }
    }

    if (showSheet && detail != null) {
        EnrollSheet(
            catalog = catalog,
            owned = detail.courses.map { it.id }.toSet(),
            onDismiss = { showSheet = false },
            onPick = { change ->
                showSheet = false
                pending = change
            },
        )
    }

    pending?.let { p ->
        val name = detail?.user?.name ?: "el alumno"
        AlertDialog(
            onDismissRequest = { pending = null },
            icon = { Icon(if (p.enroll) Icons.Rounded.PersonAdd else Icons.Rounded.DeleteOutline, null) },
            title = { Text(if (p.enroll) "¿Matricular a $name?" else "¿Dar de baja a $name?") },
            text = {
                Text(
                    when {
                        p.enroll && p.bundleId > 0 -> "Se inscribirá en todos los cursos del paquete “${p.title}”."
                        p.enroll -> "Se inscribirá en el curso “${p.title}” y lo verá de inmediato en Mis cursos."
                        p.bundleId > 0 -> "Perderá el acceso a todos los cursos del paquete “${p.title}”, incluso si compró alguno por separado. Su avance se conserva por si vuelve a inscribirse."
                        else -> "Perderá el acceso al curso “${p.title}”. Su avance se conserva por si vuelve a inscribirse."
                    },
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        vm.apply(p)
                        pending = null
                    },
                    colors = if (p.enroll) ButtonDefaults.buttonColors() else ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.error,
                        contentColor = MaterialTheme.colorScheme.onError,
                    ),
                ) { Text(if (p.enroll) "Matricular" else "Dar de baja") }
            },
            dismissButton = { TextButton(onClick = { pending = null }) { Text("Cancelar") } },
        )
    }
}

@Composable
private fun UserDetail(
    d: AdminUserDetail,
    onRemoveCourse: (AdminCourse) -> Unit,
    onRemoveBundle: (Long, String) -> Unit,
) {
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 96.dp)) {
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                shape = MaterialTheme.shapes.large,
                modifier = Modifier.fillMaxWidth(),
            ) {
                Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Avatar(d.user.avatar, 56)
                    Spacer(Modifier.width(14.dp))
                    Column(Modifier.weight(1f)) {
                        Text(d.user.name, style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.onPrimaryContainer)
                        Text(d.user.email, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onPrimaryContainer)
                        Text(
                            "Alumno desde ${d.user.since} · ${d.courses.size} cursos",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = .8f),
                        )
                    }
                }
            }
        }

        if (d.bundles.isNotEmpty()) {
            item { Heading("Paquetes") }
            items(d.bundles, key = { "b${it.id}" }) { b ->
                Row(
                    Modifier.fillMaxWidth().padding(vertical = 4.dp).clip(MaterialTheme.shapes.medium)
                        .background(MaterialTheme.colorScheme.surfaceContainerLow).padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Icon(Icons.Rounded.Inventory2, null, tint = MaterialTheme.colorScheme.primary)
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(b.title, style = MaterialTheme.typography.titleSmall)
                        Text(
                            if (b.have >= b.count) "Completo · ${b.count} cursos" else "Tiene ${b.have} de ${b.count} cursos",
                            style = MaterialTheme.typography.bodySmall,
                            color = if (b.have >= b.count) SuccessGreen else MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                    OutlinedButton(
                        onClick = { onRemoveBundle(b.id, b.title) },
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.error),
                    ) { Text("Dar de baja") }
                }
            }
        }

        item { Heading("Cursos inscritos (${d.courses.size})") }
        if (d.courses.isEmpty()) {
            item {
                EmptyState(Icons.Rounded.School, "Sin cursos", "Usa el botón Matricular para inscribirlo en un curso o paquete.")
            }
        }
        items(d.courses, key = { "c${it.id}" }) { c ->
            Row(
                Modifier.fillMaxWidth().padding(vertical = 4.dp).clip(MaterialTheme.shapes.medium)
                    .background(MaterialTheme.colorScheme.surfaceContainerLowest).padding(10.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                NetImage(c.thumb, Modifier.size(56.dp).clip(MaterialTheme.shapes.small))
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(c.title, style = MaterialTheme.typography.titleSmall, maxLines = 2, overflow = TextOverflow.Ellipsis)
                    Text(
                        (if (c.category.isNotBlank()) c.category + " · " else "") + "${c.progress}% de avance",
                        style = MaterialTheme.typography.bodySmall,
                        color = if (c.progress >= 100) SuccessGreen else MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                IconButton(onClick = { onRemoveCourse(c) }) {
                    Icon(Icons.Rounded.DeleteOutline, "Dar de baja", tint = MaterialTheme.colorScheme.error)
                }
            }
        }
    }
}

@Composable
private fun Heading(text: String) {
    Text(
        text,
        style = MaterialTheme.typography.titleMedium,
        fontWeight = FontWeight.SemiBold,
        modifier = Modifier.padding(top = 20.dp, bottom = 6.dp),
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun EnrollSheet(
    catalog: AdminCatalog?,
    owned: Set<Long>,
    onDismiss: () -> Unit,
    onPick: (PendingChange) -> Unit,
) {
    val sheet = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    var mode by remember { mutableIntStateOf(0) }
    var q by remember { mutableStateOf("") }
    ModalBottomSheet(onDismissRequest = onDismiss, sheetState = sheet) {
        Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp)) {
            Text("Matricular alumno", style = MaterialTheme.typography.titleLarge)
            Spacer(Modifier.height(12.dp))
            SingleChoiceSegmentedButtonRow(Modifier.fillMaxWidth()) {
                SegmentedButton(selected = mode == 0, onClick = { mode = 0 }, shape = SegmentedButtonDefaults.itemShape(0, 2)) { Text("Por curso") }
                SegmentedButton(selected = mode == 1, onClick = { mode = 1 }, shape = SegmentedButtonDefaults.itemShape(1, 2)) { Text("Por paquete") }
            }
            OutlinedTextField(
                value = q,
                onValueChange = { q = it },
                placeholder = { Text(if (mode == 0) "Buscar curso" else "Buscar paquete") },
                leadingIcon = { Icon(Icons.Rounded.Search, null) },
                singleLine = true,
                shape = CircleShape,
                modifier = Modifier.fillMaxWidth().padding(vertical = 12.dp),
            )
            if (catalog == null) {
                Box(Modifier.fillMaxWidth().padding(32.dp), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
            } else {
                val term = q.trim().lowercase()
                LazyColumn(Modifier.fillMaxWidth().heightIn(max = 460.dp), contentPadding = PaddingValues(bottom = 32.dp)) {
                    if (mode == 0) {
                        val list = catalog.courses.filter { term.isEmpty() || it.title.lowercase().contains(term) || it.category.lowercase().contains(term) }
                        items(list, key = { "c${it.id}" }) { c ->
                            val has = c.id in owned
                            ListItem(
                                headlineContent = { Text(c.title, maxLines = 2, overflow = TextOverflow.Ellipsis) },
                                supportingContent = { Text(if (has) "Ya inscrito" else c.category, color = if (has) SuccessGreen else Color.Unspecified) },
                                leadingContent = { NetImage(c.thumb, Modifier.size(44.dp).clip(MaterialTheme.shapes.small)) },
                                colors = ListItemDefaults.colors(containerColor = Color.Transparent),
                                modifier = Modifier.clip(MaterialTheme.shapes.medium).clickable(enabled = !has) {
                                    onPick(PendingChange(true, c.title, courseId = c.id))
                                },
                            )
                        }
                    } else {
                        val list = catalog.bundles.filter { term.isEmpty() || it.title.lowercase().contains(term) }
                        items(list, key = { "b${it.id}" }) { b ->
                            ListItem(
                                headlineContent = { Text(b.title) },
                                supportingContent = { Text("${b.count} cursos" + if (b.isPrivate) " · privado (no se muestra en la tienda)" else "") },
                                leadingContent = { Icon(Icons.Rounded.Inventory2, null, tint = MaterialTheme.colorScheme.primary) },
                                colors = ListItemDefaults.colors(containerColor = Color.Transparent),
                                modifier = Modifier.clip(MaterialTheme.shapes.medium).clickable {
                                    onPick(PendingChange(true, b.title, bundleId = b.id))
                                },
                            )
                        }
                    }
                }
            }
        }
    }
}
