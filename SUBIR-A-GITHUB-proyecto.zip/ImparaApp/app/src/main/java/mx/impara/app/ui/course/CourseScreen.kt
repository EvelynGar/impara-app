package mx.impara.app.ui.course

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.Description
import androidx.compose.material.icons.rounded.ExpandLess
import androidx.compose.material.icons.rounded.ExpandMore
import androidx.compose.material.icons.rounded.Group
import androidx.compose.material.icons.rounded.Inventory2
import androidx.compose.material.icons.rounded.PlayCircle
import androidx.compose.material.icons.rounded.PlayLesson
import androidx.compose.material.icons.rounded.Quiz
import androidx.compose.material.icons.rounded.Schedule
import androidx.compose.material.icons.rounded.ShoppingCart
import androidx.compose.material.icons.rounded.Verified
import androidx.compose.material.icons.rounded.WorkspacePremium
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import mx.impara.app.data.ApiException
import mx.impara.app.data.CourseDetail
import mx.impara.app.data.Repository
import mx.impara.app.data.Section
import mx.impara.app.data.WebTarget
import mx.impara.app.ui.LocalActions
import mx.impara.app.ui.LocalRepository
import mx.impara.app.ui.components.ErrorState
import mx.impara.app.ui.components.NetImage
import mx.impara.app.ui.components.Pill
import mx.impara.app.ui.components.PriceRow
import mx.impara.app.ui.components.ProgressLine
import mx.impara.app.ui.components.Skeleton
import mx.impara.app.ui.components.UiState
import mx.impara.app.ui.components.money
import mx.impara.app.ui.components.number
import mx.impara.app.ui.theme.ImparaOrange
import mx.impara.app.ui.theme.ImparaPurple
import mx.impara.app.ui.theme.ImparaPurpleDeep
import mx.impara.app.ui.theme.SuccessGreen

class CourseViewModel(private val repo: Repository, private val id: Long) : ViewModel() {
    private val _state = MutableStateFlow<UiState<CourseDetail>>(UiState.Loading)
    val state = _state.asStateFlow()

    init {
        viewModelScope.launch { repo.version.collect { load() } }
    }

    fun refresh() {
        viewModelScope.launch { load() }
    }

    private suspend fun load() {
        val current = _state.value
        if (current !is UiState.Ready) _state.value = UiState.Loading
        _state.value = try {
            UiState.Ready(repo.course(id))
        } catch (e: ApiException) {
            if (current is UiState.Ready) current else UiState.Error(e.message ?: "")
        }
    }
}

@Composable
fun CourseScreen(id: Long) {
    val repo = LocalRepository.current
    val actions = LocalActions.current
    val vm: CourseViewModel = viewModel(key = "course-$id") { CourseViewModel(repo, id) }
    val state by vm.state.collectAsStateWithLifecycle()
    val session by repo.session.collectAsStateWithLifecycle()
    var askLogin by remember { mutableStateOf(false) }

    val course = (state as? UiState.Ready)?.data

    fun buy(c: CourseDetail) {
        if (session == null) askLogin = true
        else actions.web(WebTarget(title = "Pago seguro", productId = c.product_id))
    }

    Scaffold(
        bottomBar = {
            if (course != null) {
                BuyBar(
                    course,
                    isAdmin = session?.user?.admin == true,
                    onBuy = { buy(course) },
                    onContinue = { actions.learn(course.id) },
                    onSite = { actions.web(course.title, course.url) },
                )
            }
        },
    ) { padding ->
        when (val s = state) {
            UiState.Loading -> CourseSkeleton()
            is UiState.Error -> Box(Modifier.fillMaxSize()) {
                ErrorState(s.message, vm::refresh)
                BackButton(Modifier.statusBarsPadding().padding(8.dp)) { actions.back() }
            }
            is UiState.Ready -> CourseContent(s.data, PaddingValues(bottom = padding.calculateBottomPadding() + 16.dp))
        }
    }

    if (askLogin && course != null) {
        AlertDialog(
            onDismissRequest = { askLogin = false },
            icon = { Icon(Icons.Rounded.ShoppingCart, null) },
            title = { Text("Inicia sesión para comprar") },
            text = {
                Text("Así el curso aparecerá en \"Mis cursos\" de la app en cuanto termines el pago. Si aún no tienes cuenta, puedes crearla en un minuto.")
            },
            confirmButton = {
                Button(onClick = {
                    askLogin = false
                    actions.login()
                }) { Text("Iniciar sesión") }
            },
            dismissButton = {
                TextButton(onClick = {
                    askLogin = false
                    actions.web(WebTarget(title = "Pago seguro", productId = course.product_id))
                }) { Text("Comprar sin cuenta") }
            },
        )
    }
}

@Composable
private fun BackButton(modifier: Modifier = Modifier, onClick: () -> Unit) {
    FilledIconButton(
        onClick = onClick,
        modifier = modifier,
        colors = IconButtonDefaults.filledIconButtonColors(
            containerColor = Color.Black.copy(alpha = .35f),
            contentColor = Color.White,
        ),
    ) { Icon(Icons.AutoMirrored.Rounded.ArrowBack, "Regresar") }
}

@Composable
private fun CourseContent(c: CourseDetail, contentPadding: PaddingValues) {
    val actions = LocalActions.current
    var expanded by remember(c.id) { mutableStateOf(setOf(0)) }
    var showAllText by rememberSaveable { mutableStateOf(false) }

    LazyColumn(Modifier.fillMaxSize(), contentPadding = contentPadding) {
        item {
            Box {
                NetImage(c.thumb, Modifier.fillMaxWidth().aspectRatio(1.5f))
                Box(
                    Modifier
                        .matchParentSize()
                        .background(Brush.verticalGradient(listOf(Color.Black.copy(alpha = .35f), Color.Transparent, Color.Transparent))),
                )
                BackButton(Modifier.statusBarsPadding().padding(8.dp)) { actions.back() }
            }
        }
        item {
            Column(Modifier.padding(16.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (c.category.isNotBlank()) {
                        Pill(c.category, MaterialTheme.colorScheme.primaryContainer, MaterialTheme.colorScheme.onPrimaryContainer)
                    }
                    if (c.enrolled) Pill("Inscrito", SuccessGreen, Color.White, icon = Icons.Rounded.Verified)
                    else if (c.hasDiscount) Pill("Oferta", ImparaOrange, Color.White)
                }
                Spacer(Modifier.height(10.dp))
                Text(c.title, style = MaterialTheme.typography.headlineSmall)
                if (c.summary.isNotBlank()) {
                    Spacer(Modifier.height(8.dp))
                    Text(c.summary, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                Spacer(Modifier.height(16.dp))
                InfoChips(c)
                if (c.enrolled) {
                    Spacer(Modifier.height(16.dp))
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                        shape = MaterialTheme.shapes.medium,
                    ) {
                        Column(Modifier.fillMaxWidth().padding(16.dp)) {
                            Text("Tu avance", style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.onPrimaryContainer)
                            Spacer(Modifier.height(8.dp))
                            ProgressLine(c.progress ?: 0)
                        }
                    }
                }
            }
        }

        if (c.learn.isNotEmpty()) {
            item { Heading("Lo que aprenderás") }
            item {
                Column(Modifier.padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    c.learn.forEach { point ->
                        Row {
                            Icon(Icons.Rounded.CheckCircle, null, tint = SuccessGreen, modifier = Modifier.size(20.dp))
                            Spacer(Modifier.width(10.dp))
                            Text(point, style = MaterialTheme.typography.bodyMedium)
                        }
                    }
                }
            }
        }

        c.bundles.firstOrNull { !it.has }?.let { b ->
            item {
                Card(
                    onClick = { actions.bundle(b.id) },
                    modifier = Modifier.fillMaxWidth().padding(16.dp),
                    shape = MaterialTheme.shapes.large,
                    colors = CardDefaults.cardColors(containerColor = Color.Transparent),
                ) {
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .background(Brush.linearGradient(listOf(ImparaPurple, ImparaPurpleDeep)))
                            .padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Icon(Icons.Rounded.Inventory2, null, tint = Color.White, modifier = Modifier.size(32.dp))
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text("Ahorra con el paquete", style = MaterialTheme.typography.labelMedium, color = Color.White.copy(alpha = .8f))
                            Text(b.title, style = MaterialTheme.typography.titleSmall, color = Color.White, maxLines = 2, overflow = TextOverflow.Ellipsis)
                            Text(
                                "${b.count} cursos por ${money(b.price)}" + if (b.discount > 0) " (-${b.discount}%)" else "",
                                style = MaterialTheme.typography.bodySmall,
                                color = Color.White,
                            )
                        }
                    }
                }
            }
        }

        if (c.sections.isNotEmpty()) {
            item { Heading("Temario", "${c.sections.size} secciones · ${c.lessons} clases") }
            itemsIndexed(c.sections) { i, section ->
                SectionRow(
                    section,
                    open = i in expanded,
                    onToggle = { expanded = if (i in expanded) expanded - i else expanded + i },
                    onItem = if (c.enrolled) { { id -> actions.learn(c.id, id) } } else null,
                )
            }
        }

        if (c.description.isNotBlank()) {
            item { Heading("Descripción") }
            item {
                Column(Modifier.padding(horizontal = 16.dp).animateContentSize()) {
                    Text(
                        c.description,
                        style = MaterialTheme.typography.bodyMedium,
                        maxLines = if (showAllText) Int.MAX_VALUE else 6,
                        overflow = TextOverflow.Ellipsis,
                    )
                    if (c.description.length > 300) {
                        TextButton(onClick = { showAllText = !showAllText }, contentPadding = PaddingValues(0.dp)) {
                            Text(if (showAllText) "Leer menos" else "Leer más")
                        }
                    }
                }
            }
        }

        item {
            Card(
                Modifier.fillMaxWidth().padding(16.dp),
                shape = MaterialTheme.shapes.large,
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLow),
            ) {
                Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        Modifier.size(48.dp).clip(CircleShape).background(ImparaOrange.copy(alpha = .15f)),
                        contentAlignment = Alignment.Center,
                    ) { Icon(Icons.Rounded.WorkspacePremium, null, tint = ImparaOrange) }
                    Spacer(Modifier.width(12.dp))
                    Column {
                        Text("Constancia DC-3 y diploma", style = MaterialTheme.typography.titleSmall)
                        Text(
                            "Al concluir recibes tu constancia DC-3 avalada por la STPS y tu diploma.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun InfoChips(c: CourseDetail) {
    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        if (c.lessons > 0) Info(Icons.Rounded.PlayLesson, "${c.lessons} clases")
        if (c.duration.isNotBlank()) Info(Icons.Rounded.Schedule, c.duration)
        if (c.students > 0) Info(Icons.Rounded.Group, "${number(c.students)} alumnos")
        if (c.quizzes > 0) Info(Icons.Rounded.Quiz, "${c.quizzes} exámenes")
        Info(Icons.Rounded.WorkspacePremium, "DC-3")
    }
}

@Composable
private fun Info(icon: ImageVector, text: String) {
    Surface(shape = CircleShape, color = MaterialTheme.colorScheme.surfaceContainerHigh) {
        Row(Modifier.padding(horizontal = 12.dp, vertical = 7.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, null, Modifier.size(16.dp), tint = MaterialTheme.colorScheme.primary)
            Spacer(Modifier.width(6.dp))
            Text(text, style = MaterialTheme.typography.labelMedium)
        }
    }
}

@Composable
private fun Heading(title: String, subtitle: String? = null) {
    Column(Modifier.padding(start = 16.dp, end = 16.dp, top = 20.dp, bottom = 10.dp)) {
        Text(title, style = MaterialTheme.typography.titleLarge)
        if (subtitle != null) {
            Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun SectionRow(section: Section, open: Boolean, onToggle: () -> Unit, onItem: ((Long) -> Unit)? = null) {
    Column(
        Modifier
            .padding(horizontal = 16.dp, vertical = 4.dp)
            .clip(MaterialTheme.shapes.medium)
            .background(MaterialTheme.colorScheme.surfaceContainerLow),
    ) {
        Row(
            Modifier.fillMaxWidth().clickable(onClick = onToggle).padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Column(Modifier.weight(1f)) {
                Text(section.title, style = MaterialTheme.typography.titleSmall)
                Text(
                    "${section.items.size} elementos" + if (section.duration.isNotBlank()) " · ${section.duration}" else "",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
            Icon(if (open) Icons.Rounded.ExpandLess else Icons.Rounded.ExpandMore, if (open) "Cerrar" else "Abrir")
        }
        AnimatedVisibility(open) {
            Column {
                HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
                section.items.forEach { item ->
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .then(if (onItem != null && item.id > 0) Modifier.clickable { onItem(item.id) } else Modifier)
                            .padding(horizontal = 14.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Icon(
                            when (item.type) {
                                "quiz" -> Icons.Rounded.Quiz
                                "assignment" -> Icons.Rounded.Description
                                else -> Icons.Rounded.PlayCircle
                            },
                            null,
                            Modifier.size(20.dp),
                            tint = MaterialTheme.colorScheme.primary,
                        )
                        Spacer(Modifier.width(10.dp))
                        Text(item.title, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.weight(1f))
                        if (item.duration.isNotBlank()) {
                            Text(item.duration, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun BuyBar(c: CourseDetail, isAdmin: Boolean, onBuy: () -> Unit, onContinue: () -> Unit, onSite: () -> Unit) {
    Surface(tonalElevation = 3.dp, shadowElevation = 12.dp, color = MaterialTheme.colorScheme.surfaceContainerLow) {
        Row(
            Modifier.fillMaxWidth().navigationBarsPadding().padding(horizontal = 16.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            when {
                c.enrolled -> {
                    Button(onClick = onContinue, modifier = Modifier.fillMaxWidth().height(52.dp)) {
                        Icon(Icons.Rounded.PlayCircle, null)
                        Spacer(Modifier.width(8.dp))
                        Text(
                            when {
                                (c.progress ?: 0) >= 100 -> "Repasar curso"
                                (c.progress ?: 0) == 0 -> "Empezar curso"
                                else -> "Continuar curso"
                            },
                        )
                    }
                }
                isAdmin -> {
                    Button(onClick = onContinue, modifier = Modifier.fillMaxWidth().height(52.dp)) {
                        Icon(Icons.Rounded.PlayCircle, null)
                        Spacer(Modifier.width(8.dp))
                        Text("Ver clases (administrador)")
                    }
                }
                c.canBuy -> {
                    Column(Modifier.weight(1f)) {
                        Text("Pago único · acceso sin expiración", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        PriceRow(c.price, c.regular, c.on_sale, big = true)
                    }
                    Button(onClick = onBuy, modifier = Modifier.height(52.dp)) {
                        Icon(Icons.Rounded.ShoppingCart, null, Modifier.size(20.dp))
                        Spacer(Modifier.width(8.dp))
                        Text("Comprar")
                    }
                }
                else -> OutlinedButton(onClick = onSite, modifier = Modifier.fillMaxWidth().height(52.dp)) {
                    Text("Ver en el sitio")
                }
            }
        }
    }
}

@Composable
private fun CourseSkeleton() {
    Column(Modifier.fillMaxSize()) {
        Skeleton(Modifier.fillMaxWidth().aspectRatio(1.5f), androidx.compose.ui.graphics.RectangleShape)
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Skeleton(Modifier.width(90.dp).height(24.dp), CircleShape)
            Skeleton(Modifier.fillMaxWidth().height(30.dp))
            Skeleton(Modifier.fillMaxWidth(.7f).height(30.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                repeat(3) { Skeleton(Modifier.width(96.dp).height(32.dp), CircleShape) }
            }
            Spacer(Modifier.height(8.dp))
            repeat(4) { Skeleton(Modifier.fillMaxWidth().height(64.dp), MaterialTheme.shapes.medium) }
        }
    }
}
