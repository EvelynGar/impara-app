package mx.impara.app.ui.learn

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.content.pm.ActivityInfo
import android.view.View
import android.view.ViewGroup
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import androidx.activity.compose.BackHandler
import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.Description
import androidx.compose.material.icons.rounded.MenuBook
import androidx.compose.material.icons.rounded.PlayCircle
import androidx.compose.material.icons.rounded.Quiz
import androidx.compose.material.icons.rounded.RadioButtonUnchecked
import androidx.compose.material.icons.rounded.SkipNext
import androidx.compose.material.icons.rounded.SkipPrevious
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilledTonalIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.LinkAnnotation
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextLinkStyles
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.withLink
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.lifecycle.ViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import mx.impara.app.data.ApiException
import mx.impara.app.data.LearnData
import mx.impara.app.data.LearnItem
import mx.impara.app.data.LessonVideo
import mx.impara.app.data.Repository
import mx.impara.app.ui.LocalActions
import mx.impara.app.ui.LocalRepository
import mx.impara.app.ui.components.ErrorState
import mx.impara.app.ui.components.ProgressLine
import mx.impara.app.ui.components.UiState
import mx.impara.app.ui.theme.ImparaOrange
import mx.impara.app.ui.theme.SuccessGreen

/* ---------- Estado ---------- */

class LearnViewModel(private val repo: Repository, private val courseId: Long, startItem: Long) : ViewModel() {
    private val _state = MutableStateFlow<UiState<LearnData>>(UiState.Loading)
    val state = _state.asStateFlow()

    private val _current = MutableStateFlow(startItem)
    val current = _current.asStateFlow()

    private val _saving = MutableStateFlow(false)
    val saving = _saving.asStateFlow()

    init {
        load()
    }

    fun load() {
        viewModelScope.launch {
            if (_state.value !is UiState.Ready) _state.value = UiState.Loading
            _state.value = try {
                val data = repo.learn(courseId)
                val ids = data.sections.flatMap { s -> s.items.map { it.id } }
                if (_current.value == 0L || _current.value !in ids) _current.value = data.resume_id
                UiState.Ready(data)
            } catch (e: ApiException) {
                UiState.Error(e.message ?: "")
            }
        }
    }

    fun select(id: Long) {
        _current.value = id
    }

    /** Marca la clase actual como completada y pasa a la siguiente. */
    fun completeAndNext() {
        val data = (_state.value as? UiState.Ready)?.data ?: return
        val id = _current.value
        val flat = data.sections.flatMap { it.items }
        val item = flat.firstOrNull { it.id == id } ?: return
        val next = flat.getOrNull(flat.indexOfFirst { it.id == id } + 1)
        if (item.completed) {
            next?.let { _current.value = it.id }
            return
        }
        viewModelScope.launch {
            _saving.value = true
            try {
                val res = repo.complete(courseId, id)
                _state.update { s ->
                    if (s !is UiState.Ready) s
                    else s.copy(
                        data = s.data.copy(
                            progress = res.progress,
                            sections = s.data.sections.map { sec ->
                                sec.copy(items = sec.items.map { if (it.id == id) it.copy(completed = true) else it })
                            },
                        ),
                    )
                }
                repo.invalidate()
                next?.let { _current.value = it.id }
            } catch (_: ApiException) {
                // Sin conexión: el alumno puede intentarlo de nuevo.
            } finally {
                _saving.value = false
            }
        }
    }
}

/* ---------- Pantalla ---------- */

@Composable
fun LearnScreen(courseId: Long, startItem: Long) {
    val repo = LocalRepository.current
    val actions = LocalActions.current
    val vm: LearnViewModel = viewModel(key = "learn-$courseId") { LearnViewModel(repo, courseId, startItem) }
    val state by vm.state.collectAsStateWithLifecycle()
    val currentId by vm.current.collectAsStateWithLifecycle()
    val saving by vm.saving.collectAsStateWithLifecycle()
    val context = LocalContext.current
    val activity = remember(context) { context.findActivity() }

    var fullscreenView by remember { mutableStateOf<View?>(null) }
    var fullscreenCallback by remember { mutableStateOf<WebChromeClient.CustomViewCallback?>(null) }

    fun exitFullscreen() {
        fullscreenCallback?.onCustomViewHidden()
        fullscreenView = null
        fullscreenCallback = null
    }

    // Pantalla completa: horizontal y sin barras del sistema.
    DisposableEffect(fullscreenView != null) {
        val window = activity?.window
        if (fullscreenView != null && activity != null && window != null) {
            activity.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
            WindowCompat.getInsetsController(window, window.decorView).apply {
                systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
                hide(WindowInsetsCompat.Type.systemBars())
            }
        }
        onDispose {
            if (activity != null && window != null) {
                activity.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
                WindowCompat.getInsetsController(window, window.decorView).show(WindowInsetsCompat.Type.systemBars())
            }
        }
    }

    BackHandler(enabled = fullscreenView != null) { exitFullscreen() }

    Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.surface, contentColor = MaterialTheme.colorScheme.onSurface) {
    Box(Modifier.fillMaxSize()) {
        when (val s = state) {
            UiState.Loading -> Column(Modifier.fillMaxSize()) {
                TopStrip("Cargando…", null) { actions.back() }
                Box(Modifier.fillMaxWidth().aspectRatio(16f / 9f).background(Color.Black), contentAlignment = Alignment.Center) {
                    CircularProgressIndicator(color = Color.White)
                }
            }
            is UiState.Error -> Column(Modifier.fillMaxSize()) {
                TopStrip("Mi curso", null) { actions.back() }
                ErrorState(s.message, vm::load)
            }
            is UiState.Ready -> {
                val data = s.data
                val flat = remember(data) { data.sections.flatMap { sec -> sec.items.map { sec.title to it } } }
                val index = flat.indexOfFirst { it.second.id == currentId }.coerceAtLeast(0)
                val (sectionTitle, item) = flat.getOrNull(index) ?: ("" to LearnItem())
                Column(Modifier.fillMaxSize()) {
                    TopStrip(data.course.title, data.progress) { actions.back() }
                    LessonPlayer(
                        item = item,
                        onOpenWeb = { actions.web(item.title, item.web_url) },
                        onFullscreen = { v, cb ->
                            fullscreenView = v
                            fullscreenCallback = cb
                        },
                        onExitFullscreen = {
                            fullscreenView = null
                            fullscreenCallback = null
                        },
                    )
                    LessonBody(
                        data = data,
                        item = item,
                        sectionTitle = sectionTitle,
                        hasPrev = index > 0,
                        hasNext = index < flat.size - 1,
                        saving = saving,
                        onPrev = { flat.getOrNull(index - 1)?.let { vm.select(it.second.id) } },
                        onNext = { flat.getOrNull(index + 1)?.let { vm.select(it.second.id) } },
                        onComplete = vm::completeAndNext,
                        onSelect = vm::select,
                        modifier = Modifier.weight(1f),
                    )
                }
            }
        }

        fullscreenView?.let { v ->
            Box(Modifier.fillMaxSize().background(Color.Black)) {
                AndroidView(
                    factory = {
                        FrameLayout(it).apply {
                            (v.parent as? ViewGroup)?.removeView(v)
                            addView(v, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))
                        }
                    },
                    modifier = Modifier.fillMaxSize(),
                )
            }
        }
    }
    }
}

@Composable
private fun TopStrip(title: String, progress: Int?, onBack: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .background(Color.Black)
            .statusBarsPadding()
            .padding(end = 16.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Rounded.ArrowBack, "Regresar", tint = Color.White) }
        Text(
            title,
            color = Color.White,
            style = MaterialTheme.typography.titleSmall,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.weight(1f),
        )
        if (progress != null) {
            Text("$progress%", color = Color.White.copy(alpha = .8f), style = MaterialTheme.typography.labelLarge)
        }
    }
}

/* ---------- Reproductor ---------- */

@Composable
private fun LessonPlayer(
    item: LearnItem,
    onOpenWeb: () -> Unit,
    onFullscreen: (View, WebChromeClient.CustomViewCallback) -> Unit,
    onExitFullscreen: () -> Unit,
) {
    val box = Modifier.fillMaxWidth().aspectRatio(16f / 9f).background(Color.Black)
    when {
        item.type != "lesson" -> Box(box, contentAlignment = Alignment.Center) {
            Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.padding(16.dp)) {
                Icon(if (item.type == "quiz") Icons.Rounded.Quiz else Icons.Rounded.Description, null, tint = Color.White, modifier = Modifier.size(40.dp))
                Spacer(Modifier.height(8.dp))
                Text(
                    if (item.type == "quiz") "Examen" else "Tarea",
                    color = Color.White,
                    style = MaterialTheme.typography.titleMedium,
                )
                Spacer(Modifier.height(8.dp))
                Button(onClick = onOpenWeb) { Text(if (item.type == "quiz") "Resolver examen" else "Abrir tarea") }
            }
        }
        item.video == null || item.video.url.isBlank() -> Box(box, contentAlignment = Alignment.Center) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(Icons.Rounded.MenuBook, null, tint = Color.White, modifier = Modifier.size(40.dp))
                Spacer(Modifier.height(8.dp))
                Text("Lección de lectura", color = Color.White, style = MaterialTheme.typography.titleMedium)
            }
        }
        else -> item.video?.let { VideoView(it, onFullscreen, onExitFullscreen, box) }
    }
}

@SuppressLint("SetJavaScriptEnabled")
@Composable
private fun VideoView(
    video: LessonVideo,
    onFullscreen: (View, WebChromeClient.CustomViewCallback) -> Unit,
    onExitFullscreen: () -> Unit,
    modifier: Modifier,
) {
    val context = LocalContext.current
    val webView = remember {
        WebView(context).apply {
            layoutParams = ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
            setBackgroundColor(android.graphics.Color.BLACK)
            settings.javaScriptEnabled = true
            settings.loadWithOverviewMode = true
            settings.useWideViewPort = true
            settings.domStorageEnabled = true
            settings.mediaPlaybackRequiresUserGesture = false
            android.webkit.CookieManager.getInstance().setAcceptThirdPartyCookies(this, true)
            webViewClient = object : WebViewClient() {
                // El reproductor no navega a otras páginas: todo se queda en la app.
                // El reproductor no sale a otras páginas: solo se permiten los servidores de video.
                override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                    val host = request.url.host.orEmpty()
                    val allowed = listOf("mediadelivery.net", "youtube-nocookie.com", "youtube.com", "streamable.com", "mega.nz", "impara-academy.com.mx")
                    return request.isForMainFrame && allowed.none { host == it || host.endsWith(".$it") }
                }
            }
            webChromeClient = object : WebChromeClient() {
                override fun onShowCustomView(view: View, callback: CustomViewCallback) = onFullscreen(view, callback)
                override fun onHideCustomView() = onExitFullscreen()
            }
        }
    }
    LaunchedEffect(video.url) {
        if (video.type == "file") {
            webView.loadDataWithBaseURL(Repository.SITE, playerHtml(video), "text/html", "utf-8", null)
        } else {
            // Se abre directamente el reproductor del proveedor (Bunny, YouTube…) indicando que viene de tu sitio.
            webView.loadUrl(video.url, mapOf("Referer" to Repository.SITE))
        }
    }
    DisposableEffect(webView) {
        onDispose {
            webView.stopLoading()
            webView.loadUrl("about:blank")
            webView.destroy()
        }
    }
    AndroidView(factory = { webView }, modifier = modifier)
}

private fun playerHtml(v: LessonVideo): String {
    val u = v.url.replace("\"", "%22").replace("<", "%3C")
    val media = if (v.type == "file") {
        """<video src="$u" controls autoplay playsinline controlslist="nodownload" oncontextmenu="return false"></video>"""
    } else {
        """<iframe src="$u" allow="accelerometer; gyroscope; autoplay; encrypted-media; picture-in-picture; fullscreen" allowfullscreen referrerpolicy="origin"></iframe>"""
    }
    return """<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<style>html,body{margin:0;height:100%;background:#000;overflow:hidden}iframe,video{position:absolute;top:0;left:0;width:100%;height:100%;border:0;background:#000}</style>
</head><body>$media</body></html>"""
}

/* ---------- Contenido debajo del video ---------- */

@Composable
private fun LessonBody(
    data: LearnData,
    item: LearnItem,
    sectionTitle: String,
    hasPrev: Boolean,
    hasNext: Boolean,
    saving: Boolean,
    onPrev: () -> Unit,
    onNext: () -> Unit,
    onComplete: () -> Unit,
    onSelect: (Long) -> Unit,
    modifier: Modifier,
) {
    val list = rememberLazyListState()
    LaunchedEffect(item.id) { list.animateScrollToItem(0) }
    val linkColor = MaterialTheme.colorScheme.primary
    LazyColumn(modifier.fillMaxWidth(), state = list, contentPadding = PaddingValues(bottom = 24.dp)) {
        item {
            Column(Modifier.padding(16.dp)) {
                ProgressLine(data.progress)
                Spacer(Modifier.height(14.dp))
                if (sectionTitle.isNotBlank()) {
                    Text(sectionTitle.uppercase(), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                }
                Text(item.title, style = MaterialTheme.typography.titleLarge)
                if (item.duration.isNotBlank()) {
                    Text(item.duration, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                Spacer(Modifier.height(14.dp))
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilledTonalIconButton(onClick = onPrev, enabled = hasPrev) { Icon(Icons.Rounded.SkipPrevious, "Clase anterior") }
                    val doneColor by animateColorAsState(
                        if (item.completed) SuccessGreen else MaterialTheme.colorScheme.primary,
                        label = "done",
                    )
                    Button(
                        onClick = onComplete,
                        enabled = !saving && (!item.completed || hasNext),
                        colors = ButtonDefaults.buttonColors(containerColor = doneColor),
                        modifier = Modifier.weight(1f).height(48.dp),
                    ) {
                        if (saving) {
                            CircularProgressIndicator(Modifier.size(20.dp), strokeWidth = 2.dp, color = Color.White)
                        } else {
                            Icon(Icons.Rounded.CheckCircle, null, Modifier.size(18.dp))
                            Spacer(Modifier.width(8.dp))
                            Text(
                                when {
                                    item.completed && hasNext -> "Completada · siguiente"
                                    item.completed -> "Completada"
                                    hasNext -> "Completar y continuar"
                                    else -> "Marcar como completada"
                                },
                                maxLines = 1,
                            )
                        }
                    }
                    FilledTonalIconButton(onClick = onNext, enabled = hasNext) { Icon(Icons.Rounded.SkipNext, "Siguiente clase") }
                }
            }
        }

        if (item.content.isNotBlank()) {
            item {
                Card(
                    Modifier.fillMaxWidth().padding(horizontal = 16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLow),
                ) {
                    Column(Modifier.padding(16.dp)) {
                        Text("Material de la clase", style = MaterialTheme.typography.titleSmall)
                        Spacer(Modifier.height(6.dp))
                        Text(linkify(item.content, linkColor), style = MaterialTheme.typography.bodyMedium)
                    }
                }
            }
        }

        item {
            Text(
                "Temario del curso",
                style = MaterialTheme.typography.titleLarge,
                modifier = Modifier.padding(start = 16.dp, end = 16.dp, top = 20.dp, bottom = 4.dp),
            )
        }
        data.sections.forEach { section ->
            item(key = "s-" + section.title + section.items.firstOrNull()?.id) {
                Text(
                    section.title,
                    style = MaterialTheme.typography.labelLarge,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(start = 16.dp, end = 16.dp, top = 14.dp, bottom = 4.dp),
                )
            }
            items(section.items, key = { it.id }) { it ->
                CurriculumRow(it, selected = it.id == item.id) { onSelect(it.id) }
            }
        }
        item { Spacer(Modifier.navigationBarsPadding()) }
    }
}

@Composable
private fun CurriculumRow(item: LearnItem, selected: Boolean, onClick: () -> Unit) {
    Surface(
        color = if (selected) MaterialTheme.colorScheme.primaryContainer else Color.Transparent,
        modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp).clip(MaterialTheme.shapes.medium).clickable(onClick = onClick),
        shape = MaterialTheme.shapes.medium,
    ) {
        Row(Modifier.padding(horizontal = 12.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(
                when {
                    item.completed -> Icons.Rounded.CheckCircle
                    selected -> Icons.Rounded.PlayCircle
                    item.type == "quiz" -> Icons.Rounded.Quiz
                    item.type == "assignment" -> Icons.Rounded.Description
                    else -> Icons.Rounded.RadioButtonUnchecked
                },
                null,
                tint = when {
                    item.completed -> SuccessGreen
                    selected -> MaterialTheme.colorScheme.primary
                    else -> MaterialTheme.colorScheme.outline
                },
                modifier = Modifier.size(22.dp),
            )
            Spacer(Modifier.width(12.dp))
            Text(
                item.title,
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal,
                modifier = Modifier.weight(1f),
            )
            if (item.duration.isNotBlank()) {
                Text(item.duration, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            if (item.type != "lesson" && !item.completed) {
                Spacer(Modifier.width(6.dp))
                Box(Modifier.size(8.dp).clip(CircleShape).background(ImparaOrange))
            }
        }
    }
}

/* ---------- Utilidades ---------- */

private val urlRegex = Regex("""https?://[^\s<>"]+""")

private fun linkify(text: String, color: Color): AnnotatedString = buildAnnotatedString {
    var last = 0
    urlRegex.findAll(text).forEach { m ->
        append(text.substring(last, m.range.first))
        val url = m.value.trimEnd('.', ',', ')', ';')
        withLink(LinkAnnotation.Url(url, TextLinkStyles(SpanStyle(color = color, textDecoration = TextDecoration.Underline)))) {
            append(url)
        }
        last = m.range.first + url.length
    }
    append(text.substring(last))
}

private fun Context.findActivity(): Activity? {
    var c: Context = this
    while (c is ContextWrapper) {
        if (c is Activity) return c
        c = c.baseContext
    }
    return null
}
