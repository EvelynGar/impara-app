package mx.impara.app.ui.bundle

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.AllInclusive
import androidx.compose.material.icons.rounded.PlayLesson
import androidx.compose.material.icons.rounded.Schedule
import androidx.compose.material.icons.rounded.ShoppingCart
import androidx.compose.material.icons.rounded.Verified
import androidx.compose.material.icons.rounded.WorkspacePremium
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import mx.impara.app.data.ApiException
import mx.impara.app.data.BundleDetail
import mx.impara.app.data.Course
import mx.impara.app.data.Repository
import mx.impara.app.data.WebTarget
import mx.impara.app.ui.LocalActions
import mx.impara.app.ui.LocalRepository
import mx.impara.app.ui.components.ErrorState
import mx.impara.app.ui.components.NetImage
import mx.impara.app.ui.components.Pill
import mx.impara.app.ui.components.Skeleton
import mx.impara.app.ui.components.UiState
import mx.impara.app.ui.components.money
import mx.impara.app.ui.theme.ImparaOrange
import mx.impara.app.ui.theme.ImparaPurple
import mx.impara.app.ui.theme.ImparaPurpleDeep
import mx.impara.app.ui.theme.SuccessGreen

class BundleViewModel(private val repo: Repository, private val id: Long) : ViewModel() {
    private val _state = MutableStateFlow<UiState<BundleDetail>>(UiState.Loading)
    val state = _state.asStateFlow()

    init {
        viewModelScope.launch { repo.version.collect { load() } }
    }

    fun refresh() {
        viewModelScope.launch { load() }
    }

    private suspend fun load() {
        val current = _state.value
        if (current !is UiState.Ready) _state.value = UiState.Loading
        _state.value = try {
            UiState.Ready(repo.bundle(id))
        } catch (e: ApiException) {
            if (current is UiState.Ready) current else UiState.Error(e.message ?: "")
        }
    }
}

@Composable
fun BundleScreen(id: Long) {
    val repo = LocalRepository.current
    val actions = LocalActions.current
    val vm: BundleViewModel = viewModel(key = "bundle-$id") { BundleViewModel(repo, id) }
    val state by vm.state.collectAsStateWithLifecycle()
    val session by repo.session.collectAsStateWithLifecycle()
    var askLogin by remember { mutableStateOf(false) }
    val bundle = (state as? UiState.Ready)?.data

    Scaffold(
        bottomBar = {
            if (bundle != null && !bundle.has && bundle.product_id > 0) {
                Surface(shadowElevation = 12.dp, color = MaterialTheme.colorScheme.surfaceContainerLow) {
                    Row(
                        Modifier.fillMaxWidth().navigationBarsPadding().padding(horizontal = 16.dp, vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Column(Modifier.weight(1f)) {
                            Text("${bundle.count} cursos · pago único", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text(money(bundle.price), style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                        }
                        Button(
                            onClick = {
                                if (session == null) askLogin = true
                                else actions.web(WebTarget(title = "Pago seguro", productId = bundle.product_id))
                            },
                            modifier = Modifier.height(52.dp),
                        ) {
                            Icon(Icons.Rounded.ShoppingCart, null, Modifier.size(20.dp))
                            Spacer(Modifier.width(8.dp))
                            Text("Comprar paquete")
                        }
                    }
                }
            }
        },
    ) { padding ->
        when (val s = state) {
            UiState.Loading -> Column(Modifier.fillMaxSize()) {
                Skeleton(Modifier.fillMaxWidth().height(320.dp), RoundedCornerShape(bottomStart = 28.dp, bottomEnd = 28.dp))
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    repeat(5) { Skeleton(Modifier.fillMaxWidth().height(76.dp), MaterialTheme.shapes.medium) }
                }
            }
            is UiState.Error -> Box(Modifier.fillMaxSize()) {
                ErrorState(s.message, vm::refresh)
                Back(Modifier.statusBarsPadding().padding(8.dp)) { actions.back() }
            }
            is UiState.Ready -> BundleContent(s.data, PaddingValues(bottom = padding.calculateBottomPadding() + 16.dp))
        }
    }

    if (askLogin && bundle != null) {
        AlertDialog(
            onDismissRequest = { askLogin = false },
            icon = { Icon(Icons.Rounded.ShoppingCart, null) },
            title = { Text("Inicia sesión para comprar") },
            text = { Text("Así los cursos del paquete aparecerán en \"Mis cursos\" de la app en cuanto termines el pago.") },
            confirmButton = {
                Button(onClick = {
                    askLogin = false
                    actions.login()
                }) { Text("Iniciar sesión") }
            },
            dismissButton = {
                TextButton(onClick = {
                    askLogin = false
                    actions.web(WebTarget(title = "Pago seguro", productId = bundle.product_id))
                }) { Text("Comprar sin cuenta") }
            },
        )
    }
}

@Composable
private fun Back(modifier: Modifier = Modifier, onClick: () -> Unit) {
    FilledIconButton(
        onClick = onClick,
        modifier = modifier,
        colors = IconButtonDefaults.filledIconButtonColors(containerColor = Color.Black.copy(alpha = .3f), contentColor = Color.White),
    ) { Icon(Icons.AutoMirrored.Rounded.ArrowBack, "Regresar") }
}

@Composable
private fun BundleContent(b: BundleDetail, contentPadding: PaddingValues) {
    val actions = LocalActions.current
    LazyColumn(Modifier.fillMaxSize(), contentPadding = contentPadding) {
        item {
            Box(
                Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(bottomStart = 28.dp, bottomEnd = 28.dp))
                    .background(Brush.linearGradient(listOf(ImparaPurple, ImparaPurpleDeep))),
            ) {
                Column(Modifier.statusBarsPadding().padding(16.dp)) {
                    Back { actions.back() }
                    Spacer(Modifier.height(12.dp))
                    Pill("Diplomado / paquete", Color.White.copy(alpha = .16f), Color.White)
                    Spacer(Modifier.height(10.dp))
                    Text(b.title, style = MaterialTheme.typography.headlineMedium, color = Color.White)
                    Spacer(Modifier.height(6.dp))
                    Text(
                        "Todos los cursos de la ruta, con constancia DC-3 y diploma por curso.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = Color.White.copy(alpha = .85f),
                    )
                    Spacer(Modifier.height(16.dp))
                    if (b.has) {
                        Pill("Ya tienes todos los cursos", SuccessGreen, Color.White, icon = Icons.Rounded.Verified)
                    } else {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            Text(money(b.price), style = MaterialTheme.typography.displaySmall, color = Color.White)
                            Column {
                                if (b.value > b.price) {
                                    Text(
                                        money(b.value),
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = Color.White.copy(alpha = .7f),
                                        textDecoration = TextDecoration.LineThrough,
                                    )
                                }
                                if (b.discount > 0) Pill("Ahorras ${b.discount}%", ImparaOrange, Color.White)
                            }
                        }
                    }
                    Spacer(Modifier.height(16.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Fact(Icons.Rounded.PlayLesson, "${b.count} cursos", Modifier.weight(1f))
                        Fact(Icons.Rounded.Schedule, b.duration.ifBlank { "${b.lessons} clases" }, Modifier.weight(1f))
                        Fact(Icons.Rounded.AllInclusive, "Sin expirar", Modifier.weight(1f))
                    }
                }
            }
        }
        if (b.owned in 1 until b.count) {
            item {
                Card(
                    Modifier.fillMaxWidth().padding(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                ) {
                    Text(
                        "Ya tienes ${b.owned} de ${b.count} cursos de este paquete.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onPrimaryContainer,
                        modifier = Modifier.padding(16.dp),
                    )
                }
            }
        }
        item {
            Text(
                "Cursos incluidos",
                style = MaterialTheme.typography.titleLarge,
                modifier = Modifier.padding(start = 16.dp, end = 16.dp, top = 20.dp, bottom = 8.dp),
            )
        }
        items(b.courses, key = { it.id }) { c -> IncludedCourse(c) { actions.course(c.id) } }
        item {
            Card(
                Modifier.fillMaxWidth().padding(16.dp),
                shape = MaterialTheme.shapes.large,
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLow),
            ) {
                Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Rounded.WorkspacePremium, null, tint = ImparaOrange, modifier = Modifier.size(36.dp))
                    Spacer(Modifier.width(12.dp))
                    Text(
                        "Recibe tu constancia DC-3 avalada por la STPS y un diploma por cada curso que concluyas.",
                        style = MaterialTheme.typography.bodyMedium,
                    )
                }
            }
        }
    }
}

@Composable
private fun Fact(icon: ImageVector, text: String, modifier: Modifier) {
    Column(
        modifier.clip(MaterialTheme.shapes.medium).background(Color.White.copy(alpha = .12f)).padding(vertical = 10.dp, horizontal = 6.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Icon(icon, null, tint = Color.White, modifier = Modifier.size(20.dp))
        Spacer(Modifier.height(4.dp))
        Text(text, style = MaterialTheme.typography.labelMedium, color = Color.White, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
private fun IncludedCourse(c: Course, onClick: () -> Unit) {
    Card(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 5.dp),
        shape = MaterialTheme.shapes.medium,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLowest),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
    ) {
        Row(Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
            NetImage(c.thumb, Modifier.size(64.dp).clip(MaterialTheme.shapes.small))
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(c.title, style = MaterialTheme.typography.titleSmall, maxLines = 2, overflow = TextOverflow.Ellipsis)
                if (c.enrolled) {
                    Text("Ya lo tienes", style = MaterialTheme.typography.labelMedium, color = SuccessGreen)
                } else if (c.price > 0) {
                    Text(
                        "Precio individual ${money(c.price)}",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
            if (c.enrolled) {
                Box(Modifier.size(28.dp).clip(CircleShape).background(SuccessGreen), contentAlignment = Alignment.Center) {
                    Icon(Icons.Rounded.Verified, null, tint = Color.White, modifier = Modifier.size(18.dp))
                }
            }
        }
    }
}
