package mx.impara.app.ui.components

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AdminPanelSettings
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.Explore
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material.icons.rounded.PlayCircle
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.School
import androidx.compose.material.icons.rounded.Verified
import androidx.compose.material.icons.rounded.WifiOff
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.AsyncImage
import coil.request.ImageRequest
import mx.impara.app.data.Bundle
import mx.impara.app.ui.LocalRepository
import mx.impara.app.data.Course
import mx.impara.app.ui.theme.ImparaOrange
import mx.impara.app.ui.theme.ImparaPurple
import mx.impara.app.ui.theme.ImparaPurpleDeep
import mx.impara.app.ui.theme.SuccessGreen
import java.text.NumberFormat
import java.util.Locale

/* ---------- Formato ---------- */

private val mx = Locale("es", "MX")

fun money(v: Double): String {
    val nf = NumberFormat.getCurrencyInstance(mx)
    val decimals = if (v % 1.0 == 0.0) 0 else 2
    nf.minimumFractionDigits = decimals
    nf.maximumFractionDigits = decimals
    return nf.format(v)
}

fun number(n: Int): String = NumberFormat.getIntegerInstance(mx).format(n)

/* ---------- Estado de pantalla ---------- */

sealed interface UiState<out T> {
    data object Loading : UiState<Nothing>
    data class Error(val message: String) : UiState<Nothing>
    data class Ready<T>(val data: T, val refreshing: Boolean = false) : UiState<T>
}

/* ---------- Imágenes ---------- */

@Composable
fun NetImage(url: String, modifier: Modifier = Modifier, contentScale: ContentScale = ContentScale.Crop) {
    Box(
        modifier.background(
            Brush.linearGradient(listOf(ImparaPurple.copy(alpha = .85f), ImparaPurpleDeep)),
        ),
        contentAlignment = Alignment.Center,
    ) {
        if (url.isBlank()) {
            Icon(Icons.Rounded.School, null, tint = Color.White.copy(alpha = .8f), modifier = Modifier.size(36.dp))
        } else {
            AsyncImage(
                model = ImageRequest.Builder(LocalContext.current).data(url).crossfade(true).build(),
                contentDescription = null,
                contentScale = contentScale,
                modifier = Modifier.fillMaxSize(),
            )
        }
    }
}

/* ---------- Precio ---------- */

@Composable
fun PriceRow(price: Double, regular: Double, onSale: Boolean, big: Boolean = false) {
    if (price <= 0) return
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(
            money(price),
            style = if (big) MaterialTheme.typography.headlineSmall else MaterialTheme.typography.titleMedium,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onSurface,
        )
        if (onSale && regular > price) {
            Text(
                money(regular),
                style = MaterialTheme.typography.bodySmall,
                textDecoration = TextDecoration.LineThrough,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}

@Composable
fun Pill(text: String, container: Color, content: Color, modifier: Modifier = Modifier, icon: ImageVector? = null) {
    Surface(color = container, contentColor = content, shape = CircleShape, modifier = modifier) {
        Row(
            Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(4.dp),
        ) {
            if (icon != null) Icon(icon, null, modifier = Modifier.size(14.dp))
            Text(text, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.SemiBold)
        }
    }
}

@Composable
fun ProgressLine(percent: Int, modifier: Modifier = Modifier) {
    Column(modifier) {
        LinearProgressIndicator(
            progress = { (percent.coerceIn(0, 100)) / 100f },
            modifier = Modifier.fillMaxWidth().height(6.dp).clip(CircleShape),
            trackColor = MaterialTheme.colorScheme.surfaceContainerHighest,
            drawStopIndicator = {},
            gapSize = 0.dp,
        )
        Spacer(Modifier.height(4.dp))
        Text(
            if (percent >= 100) "Curso completado" else "$percent% completado",
            style = MaterialTheme.typography.labelSmall,
            color = if (percent >= 100) SuccessGreen else MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}

/* ---------- Tarjetas ---------- */

/** Tarjeta de curso para cuadrículas y carruseles. */
@Composable
fun CourseCard(course: Course, onClick: () -> Unit, modifier: Modifier = Modifier) {
    Card(
        onClick = onClick,
        modifier = modifier,
        shape = MaterialTheme.shapes.medium,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLowest),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
    ) {
        Box {
            NetImage(course.thumb, Modifier.fillMaxWidth().aspectRatio(1.4f))
            when {
                course.enrolled -> Pill(
                    "Inscrito", SuccessGreen, Color.White,
                    Modifier.align(Alignment.TopStart).padding(8.dp), Icons.Rounded.Verified,
                )
                course.hasDiscount -> Pill(
                    "-${(((course.regular - course.price) / course.regular) * 100).toInt()}%",
                    ImparaOrange, Color.White, Modifier.align(Alignment.TopStart).padding(8.dp),
                )
            }
        }
        Column(Modifier.padding(12.dp)) {
            if (course.category.isNotBlank()) {
                Text(
                    course.category.uppercase(),
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.primary,
                    maxLines = 1,
                )
                Spacer(Modifier.height(2.dp))
            }
            Text(
                course.title,
                style = MaterialTheme.typography.titleSmall,
                maxLines = 2,
                minLines = 2,
                overflow = TextOverflow.Ellipsis,
            )
            Spacer(Modifier.height(8.dp))
            if (course.enrolled) {
                if (course.progress != null) {
                    ProgressLine(course.progress)
                } else {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Rounded.PlayCircle, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(4.dp))
                        Text("Continuar", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary)
                    }
                }
            } else {
                PriceRow(course.price, course.regular, course.on_sale)
            }
        }
    }
}

/** Fila compacta para "Continúa aprendiendo" y "Mis cursos". */
@Composable
fun CourseProgressCard(course: Course, onClick: () -> Unit, onContinue: () -> Unit, modifier: Modifier = Modifier) {
    Card(
        onClick = onClick,
        modifier = modifier,
        shape = MaterialTheme.shapes.medium,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerLowest),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
    ) {
        Row(Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
            NetImage(course.thumb, Modifier.size(84.dp).clip(MaterialTheme.shapes.small))
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    course.title,
                    style = MaterialTheme.typography.titleSmall,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                )
                Spacer(Modifier.height(6.dp))
                ProgressLine(course.progress ?: 0)
                Spacer(Modifier.height(4.dp))
                TextButton(onClick = onContinue, contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 0.dp)) {
                    Icon(
                        if ((course.progress ?: 0) >= 100) Icons.Rounded.CheckCircle else Icons.Rounded.PlayCircle,
                        null,
                        modifier = Modifier.size(18.dp),
                    )
                    Spacer(Modifier.width(6.dp))
                    Text(
                        when {
                            (course.progress ?: 0) >= 100 -> "Repasar curso"
                            (course.progress ?: 0) == 0 -> "Empezar curso"
                            else -> "Continuar curso"
                        },
                    )
                }
            }
        }
    }
}

/** Tarjeta de diplomado / paquete. */
@Composable
fun BundleCard(bundle: Bundle, onClick: () -> Unit, modifier: Modifier = Modifier, width: Dp = 300.dp) {
    Card(
        onClick = onClick,
        modifier = modifier.width(width),
        shape = MaterialTheme.shapes.large,
        colors = CardDefaults.cardColors(containerColor = Color.Transparent),
    ) {
        Box(
            Modifier
                .fillMaxWidth()
                .background(Brush.linearGradient(listOf(ImparaPurple, ImparaPurpleDeep)))
                .padding(16.dp),
        ) {
            Column {
                Box(Modifier.height(44.dp)) {
                    bundle.thumbs.take(4).forEachIndexed { i, t ->
                        NetImage(
                            t,
                            Modifier
                                .offset(x = (i * 30).dp)
                                .size(44.dp)
                                .border(2.dp, ImparaPurple, CircleShape)
                                .clip(CircleShape),
                        )
                    }
                }
                Spacer(Modifier.height(12.dp))
                Text(
                    bundle.title,
                    style = MaterialTheme.typography.titleMedium,
                    color = Color.White,
                    maxLines = 2,
                    minLines = 2,
                    overflow = TextOverflow.Ellipsis,
                )
                Text(
                    "${bundle.count} cursos incluidos",
                    style = MaterialTheme.typography.bodySmall,
                    color = Color.White.copy(alpha = .8f),
                )
                Spacer(Modifier.height(12.dp))
                if (bundle.has) {
                    Pill("Ya lo tienes", SuccessGreen, Color.White, icon = Icons.Rounded.Verified)
                } else {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(
                            money(bundle.price),
                            style = MaterialTheme.typography.titleLarge,
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                        )
                        if (bundle.value > bundle.price) {
                            Text(
                                money(bundle.value),
                                style = MaterialTheme.typography.bodySmall,
                                color = Color.White.copy(alpha = .7f),
                                textDecoration = TextDecoration.LineThrough,
                            )
                        }
                        if (bundle.discount > 0) Pill("-${bundle.discount}%", ImparaOrange, Color.White)
                    }
                }
            }
        }
    }
}

/* ---------- Títulos y estados ---------- */

@Composable
fun SectionTitle(title: String, modifier: Modifier = Modifier, action: String? = null, onAction: (() -> Unit)? = null) {
    Row(
        modifier.fillMaxWidth().padding(start = 16.dp, end = 4.dp, top = 20.dp, bottom = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(title, style = MaterialTheme.typography.titleLarge, modifier = Modifier.weight(1f))
        if (action != null && onAction != null) TextButton(onClick = onAction) { Text(action) }
    }
}

@Composable
fun ErrorState(message: String, onRetry: () -> Unit, modifier: Modifier = Modifier) {
    Column(
        modifier.fillMaxSize().padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Box(
            Modifier.size(88.dp).clip(CircleShape).background(MaterialTheme.colorScheme.primaryContainer),
            contentAlignment = Alignment.Center,
        ) {
            Icon(Icons.Rounded.WifiOff, null, tint = MaterialTheme.colorScheme.onPrimaryContainer, modifier = Modifier.size(40.dp))
        }
        Spacer(Modifier.height(16.dp))
        Text("Algo salió mal", style = MaterialTheme.typography.titleLarge)
        Spacer(Modifier.height(6.dp))
        Text(message, style = MaterialTheme.typography.bodyMedium, textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(20.dp))
        Button(onClick = onRetry) {
            Icon(Icons.Rounded.Refresh, null, modifier = Modifier.size(18.dp))
            Spacer(Modifier.width(8.dp))
            Text("Reintentar")
        }
    }
}

@Composable
fun EmptyState(
    icon: ImageVector,
    title: String,
    message: String,
    modifier: Modifier = Modifier,
    action: String? = null,
    onAction: (() -> Unit)? = null,
) {
    Column(
        modifier.fillMaxWidth().padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Box(
            Modifier.size(96.dp).clip(CircleShape).background(MaterialTheme.colorScheme.primaryContainer),
            contentAlignment = Alignment.Center,
        ) {
            Icon(icon, null, tint = MaterialTheme.colorScheme.onPrimaryContainer, modifier = Modifier.size(44.dp))
        }
        Spacer(Modifier.height(16.dp))
        Text(title, style = MaterialTheme.typography.titleLarge, textAlign = TextAlign.Center)
        Spacer(Modifier.height(6.dp))
        Text(message, style = MaterialTheme.typography.bodyMedium, textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.onSurfaceVariant)
        if (action != null && onAction != null) {
            Spacer(Modifier.height(20.dp))
            Button(onClick = onAction) { Text(action) }
        }
    }
}

/** Bloque gris animado mientras carga. */
@Composable
fun Skeleton(modifier: Modifier = Modifier, shape: androidx.compose.ui.graphics.Shape = RoundedCornerShape(12.dp)) {
    val t = rememberInfiniteTransition(label = "skeleton")
    val alpha by t.animateFloat(
        initialValue = .45f,
        targetValue = .9f,
        animationSpec = infiniteRepeatable(tween(800, easing = LinearEasing), RepeatMode.Reverse),
        label = "alpha",
    )
    Box(modifier.clip(shape).background(MaterialTheme.colorScheme.surfaceContainerHighest.copy(alpha = alpha)))
}

/* ---------- Barra inferior ---------- */

enum class Tab(val route: String, val label: String, val icon: ImageVector) {
    Home("home", "Inicio", Icons.Rounded.Home),
    Explore("explore", "Explorar", Icons.Rounded.Explore),
    Mine("mine", "Mis cursos", Icons.Rounded.School),
    Profile("profile", "Perfil", Icons.Rounded.Person),
    Admin("admin", "Admin", Icons.Rounded.AdminPanelSettings),
}

@Composable
fun MainBottomBar(current: Tab, onSelect: (Tab) -> Unit) {
    NavigationBar(containerColor = MaterialTheme.colorScheme.surfaceContainerLow) {
        val session by LocalRepository.current.session.collectAsStateWithLifecycle()
        val isAdmin = session?.user?.admin == true
        Tab.entries.filter { it != Tab.Admin || isAdmin }.forEach { tab ->
            NavigationBarItem(
                selected = tab == current,
                onClick = { if (tab != current) onSelect(tab) },
                icon = { Icon(tab.icon, contentDescription = null) },
                label = { Text(tab.label, maxLines = 1) },
            )
        }
    }
}
