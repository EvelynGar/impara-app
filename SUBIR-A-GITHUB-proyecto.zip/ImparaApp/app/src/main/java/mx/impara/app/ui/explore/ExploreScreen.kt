package mx.impara.app.ui.explore

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Clear
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.SearchOff
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.drop
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import mx.impara.app.data.ApiException
import mx.impara.app.data.Category
import mx.impara.app.data.Course
import mx.impara.app.data.Repository
import mx.impara.app.ui.LocalActions
import mx.impara.app.ui.LocalRepository
import mx.impara.app.ui.components.CourseCard
import mx.impara.app.ui.components.EmptyState
import mx.impara.app.ui.components.ErrorState
import mx.impara.app.ui.components.MainBottomBar
import mx.impara.app.ui.components.Skeleton
import mx.impara.app.ui.components.Tab

data class ExploreState(
    val query: String = "",
    val cat: Long = 0,
    val categories: List<Category> = emptyList(),
    val items: List<Course> = emptyList(),
    val page: Int = 0,
    val pages: Int = 1,
    val total: Int = 0,
    val loading: Boolean = true,
    val loadingMore: Boolean = false,
    val error: String? = null,
)

class ExploreViewModel(private val repo: Repository, initialCat: Long) : ViewModel() {
    private val _state = MutableStateFlow(ExploreState(cat = initialCat))
    val state = _state.asStateFlow()
    private var job: Job? = null

    init {
        viewModelScope.launch {
            runCatching { repo.home().categories }.getOrNull()?.let { cats ->
                _state.update { it.copy(categories = cats) }
            }
        }
        reload()
        viewModelScope.launch { repo.version.drop(1).collect { reload() } }
    }

    fun setQuery(q: String) {
        _state.update { it.copy(query = q) }
        job?.cancel()
        job = viewModelScope.launch {
            delay(350)
            fetch(reset = true)
        }
    }

    fun setCategory(id: Long) {
        if (id == _state.value.cat) return
        _state.update { it.copy(cat = id) }
        reload()
    }

    fun reload() {
        job?.cancel()
        job = viewModelScope.launch { fetch(reset = true) }
    }

    fun loadMore() {
        val s = _state.value
        if (s.loading || s.loadingMore || s.error != null || s.page >= s.pages) return
        job = viewModelScope.launch { fetch(reset = false) }
    }

    private suspend fun fetch(reset: Boolean) {
        val s = _state.value
        val page = if (reset) 1 else s.page + 1
        _state.update { if (reset) it.copy(loading = true, error = null) else it.copy(loadingMore = true) }
        try {
            val res = repo.courses(cat = if (s.query.isBlank()) s.cat else 0, q = s.query, page = page)
            // Al buscar se busca en todo el catálogo; la categoría elegida filtra los resultados.
            val items = if (s.query.isNotBlank() && s.cat > 0) res.items.filter { it.category_id == s.cat } else res.items
            _state.update {
                it.copy(
                    items = if (reset) items else (it.items + items).distinctBy { c -> c.id },
                    page = page,
                    pages = res.pages.coerceAtLeast(1),
                    total = res.total,
                    loading = false,
                    loadingMore = false,
                    error = null,
                )
            }
        } catch (e: ApiException) {
            _state.update { it.copy(loading = false, loadingMore = false, error = if (reset) e.message else null) }
        }
    }
}

@Composable
fun ExploreScreen(initialCategory: Long, focusSearch: Boolean) {
    val repo = LocalRepository.current
    val actions = LocalActions.current
    val vm: ExploreViewModel = viewModel(key = "explore-$initialCategory") { ExploreViewModel(repo, initialCategory) }
    val s by vm.state.collectAsStateWithLifecycle()
    val focus = remember { FocusRequester() }
    val focusManager = LocalFocusManager.current
    val grid = rememberLazyGridState()

    LaunchedEffect(focusSearch) { if (focusSearch) runCatching { focus.requestFocus() } }

    val nearEnd by remember {
        derivedStateOf {
            val last = grid.layoutInfo.visibleItemsInfo.lastOrNull()?.index ?: 0
            last >= grid.layoutInfo.totalItemsCount - 4
        }
    }
    LaunchedEffect(grid) {
        snapshotFlow { nearEnd }.collect { if (it) vm.loadMore() }
    }

    Scaffold(
        topBar = {
            Surface(color = MaterialTheme.colorScheme.surface) {
                Column(Modifier.statusBarsPadding().padding(top = 8.dp)) {
                    Text(
                        "Explorar cursos",
                        style = MaterialTheme.typography.headlineSmall,
                        modifier = Modifier.padding(horizontal = 16.dp),
                    )
                    OutlinedTextField(
                        value = s.query,
                        onValueChange = vm::setQuery,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 10.dp)
                            .focusRequester(focus),
                        placeholder = { Text("Busca un curso o tema") },
                        leadingIcon = { Icon(Icons.Rounded.Search, null) },
                        trailingIcon = {
                            if (s.query.isNotEmpty()) {
                                IconButton(onClick = { vm.setQuery("") }) { Icon(Icons.Rounded.Clear, "Borrar búsqueda") }
                            }
                        },
                        singleLine = true,
                        shape = CircleShape,
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                        keyboardActions = KeyboardActions(onSearch = { focusManager.clearFocus() }),
                        colors = OutlinedTextFieldDefaults.colors(
                            unfocusedContainerColor = MaterialTheme.colorScheme.surfaceContainerHigh,
                            focusedContainerColor = MaterialTheme.colorScheme.surfaceContainerHigh,
                            unfocusedBorderColor = MaterialTheme.colorScheme.surfaceContainerHigh,
                        ),
                    )
                    LazyRow(
                        contentPadding = PaddingValues(horizontal = 16.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.padding(bottom = 8.dp),
                    ) {
                        item {
                            FilterChip(
                                selected = s.cat == 0L,
                                onClick = { vm.setCategory(0) },
                                label = { Text("Todos") },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = MaterialTheme.colorScheme.primary,
                                    selectedLabelColor = MaterialTheme.colorScheme.onPrimary,
                                ),
                            )
                        }
                        items(s.categories, key = { it.id }) { c ->
                            FilterChip(
                                selected = s.cat == c.id,
                                onClick = { vm.setCategory(c.id) },
                                label = { Text(c.name) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = MaterialTheme.colorScheme.primary,
                                    selectedLabelColor = MaterialTheme.colorScheme.onPrimary,
                                ),
                            )
                        }
                    }
                }
            }
        },
        bottomBar = { MainBottomBar(Tab.Explore, actions::tab) },
    ) { padding ->
        Box(Modifier.fillMaxSize().padding(padding)) {
            when {
                s.loading && s.items.isEmpty() -> LazyVerticalGrid(
                    columns = GridCells.Adaptive(160.dp),
                    contentPadding = PaddingValues(16.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    userScrollEnabled = false,
                ) {
                    items(6) { Skeleton(Modifier.fillMaxWidth().aspectRatio(0.78f), MaterialTheme.shapes.medium) }
                }
                s.error != null && s.items.isEmpty() -> ErrorState(s.error ?: "", vm::reload)
                !s.loading && s.items.isEmpty() -> EmptyState(
                    Icons.Rounded.SearchOff,
                    "Sin resultados",
                    if (s.query.isNotBlank()) "No encontramos cursos para \"${s.query}\". Prueba con otra palabra." else "Aún no hay cursos en esta categoría.",
                    Modifier.align(Alignment.TopCenter).padding(top = 24.dp),
                )
                else -> LazyVerticalGrid(
                    state = grid,
                    columns = GridCells.Adaptive(160.dp),
                    contentPadding = PaddingValues(16.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                ) {
                    item(span = { GridItemSpan(maxLineSpan) }) {
                        Text(
                            if (s.total == 1) "1 curso" else "${s.total} cursos",
                            style = MaterialTheme.typography.labelLarge,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                    items(s.items, key = { it.id }) { c ->
                        CourseCard(c, onClick = { actions.course(c.id) })
                    }
                    if (s.loadingMore) {
                        item(span = { GridItemSpan(maxLineSpan) }) {
                            Box(Modifier.fillMaxWidth().padding(16.dp), contentAlignment = Alignment.Center) {
                                CircularProgressIndicator()
                            }
                        }
                    }
                }
            }
        }
    }
}
