package mx.impara.app.ui.pdf

import android.app.DownloadManager
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Color as AColor
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.ParcelFileDescriptor
import android.webkit.URLUtil
import android.widget.Toast
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.calculatePan
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Download
import androidx.compose.material.icons.rounded.PictureAsPdf
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import mx.impara.app.ui.LocalActions
import mx.impara.app.ui.components.EmptyState
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.security.MessageDigest
import java.util.concurrent.TimeUnit

/* ---------- Documento PDF (se descarga una vez y se muestra dentro de la app) ---------- */

class PdfDoc private constructor(private val fd: ParcelFileDescriptor) {
    private val renderer = PdfRenderer(fd)
    private val lock = Mutex()
    val pageCount: Int = renderer.pageCount

    /** Proporción alto/ancho de cada página. */
    val ratios: List<Float> = (0 until pageCount).map { i ->
        renderer.openPage(i).use { p -> if (p.width > 0) p.height.toFloat() / p.width else 1.414f }
    }

    suspend fun render(index: Int, widthPx: Int): Bitmap = withContext(Dispatchers.IO) {
        lock.withLock {
            renderer.openPage(index).use { page ->
                val w = widthPx.coerceIn(400, 2200)
                val h = (w * page.height.toFloat() / page.width).toInt().coerceAtLeast(1)
                val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
                bmp.eraseColor(AColor.WHITE)
                page.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                bmp
            }
        }
    }

    fun close() {
        runCatching { renderer.close() }
        runCatching { fd.close() }
    }

    companion object {
        private val client = OkHttpClient.Builder()
            .connectTimeout(20, TimeUnit.SECONDS)
            .readTimeout(60, TimeUnit.SECONDS)
            .build()

        private fun hash(s: String): String =
            MessageDigest.getInstance("MD5").digest(s.toByteArray()).joinToString("") { "%02x".format(it) }

        suspend fun open(context: Context, url: String): PdfDoc = withContext(Dispatchers.IO) {
            val dir = File(context.cacheDir, "pdf").apply { mkdirs() }
            val file = File(dir, hash(url) + ".pdf")
            if (!file.exists() || file.length() == 0L) {
                val tmp = File(dir, file.name + ".part")
                client.newCall(Request.Builder().url(url).header("User-Agent", "ImparaApp").build()).execute().use { r ->
                    if (!r.isSuccessful) throw IllegalStateException("HTTP ${r.code}")
                    val body = r.body ?: throw IllegalStateException("Sin contenido")
                    tmp.outputStream().use { out -> body.byteStream().copyTo(out) }
                }
                tmp.renameTo(file)
            }
            PdfDoc(ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY))
        }
    }
}

private sealed interface PdfState {
    data object Loading : PdfState
    data class Ready(val doc: PdfDoc) : PdfState
    data object Error : PdfState
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PdfScreen(url: String, title: String) {
    val context = LocalContext.current
    val actions = LocalActions.current
    var state by remember { mutableStateOf<PdfState>(PdfState.Loading) }
    var attempt by remember { mutableStateOf(0) }

    LaunchedEffect(url, attempt) {
        state = PdfState.Loading
        state = try {
            PdfState.Ready(PdfDoc.open(context, url))
        } catch (e: Exception) {
            PdfState.Error
        }
    }
    val doc = (state as? PdfState.Ready)?.doc
    DisposableEffect(doc) { onDispose { doc?.close() } }

    val list = rememberLazyListState()

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(title, maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.titleMedium)
                        if (doc != null) {
                            Text(
                                "Página ${list.firstVisibleItemIndex + 1} de ${doc.pageCount}",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                    }
                },
                navigationIcon = { IconButton(onClick = { actions.back() }) { Icon(Icons.AutoMirrored.Rounded.ArrowBack, "Regresar") } },
                actions = {
                    IconButton(onClick = { downloadFile(context, url, title, "application/pdf") }) {
                        Icon(Icons.Rounded.Download, "Descargar")
                    }
                },
            )
        },
    ) { padding ->
        Box(
            Modifier
                .fillMaxSize()
                .padding(padding)
                .background(MaterialTheme.colorScheme.surfaceContainerHighest),
            contentAlignment = Alignment.Center,
        ) {
            when (val s = state) {
                PdfState.Loading -> Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    CircularProgressIndicator()
                    Text("Abriendo documento…", modifier = Modifier.padding(top = 12.dp), style = MaterialTheme.typography.bodyMedium)
                }
                PdfState.Error -> EmptyState(
                    Icons.Rounded.PictureAsPdf,
                    "No se pudo abrir el PDF",
                    "Revisa tu conexión a internet e intenta de nuevo.",
                    action = "Reintentar",
                    onAction = { attempt++ },
                )
                is PdfState.Ready -> PdfPages(s.doc, list)
            }
        }
    }
}

@Composable
private fun PdfPages(doc: PdfDoc, list: androidx.compose.foundation.lazy.LazyListState) {
    var scale by remember { mutableFloatStateOf(1f) }
    var offsetX by remember { mutableFloatStateOf(0f) }
    BoxWithConstraints(
        Modifier
            .fillMaxSize()
            // Pellizca con dos dedos para acercar; con un dedo te desplazas por las páginas.
            .pointerInput(Unit) {
                awaitEachGesture {
                    awaitFirstDown(requireUnconsumed = false)
                    do {
                        val event = awaitPointerEvent()
                        if (event.changes.count { it.pressed } >= 2) {
                            scale = (scale * event.calculateZoom()).coerceIn(1f, 4f)
                            val maxX = (scale - 1f) * size.width / 2f
                            offsetX = (offsetX + event.calculatePan().x).coerceIn(-maxX, maxX)
                            event.changes.forEach { it.consume() }
                        }
                    } while (event.changes.any { it.pressed })
                    if (scale <= 1.02f) {
                        scale = 1f
                        offsetX = 0f
                    }
                }
            },
    ) {
        val widthPx = with(LocalDensity.current) { maxWidth.toPx() }.toInt()
        LazyColumn(
            state = list,
            modifier = Modifier
                .fillMaxSize()
                .graphicsLayer {
                    scaleX = scale
                    scaleY = scale
                    translationX = offsetX
                },
            contentPadding = PaddingValues(10.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            items(doc.pageCount) { i ->
                val bitmap by produceState<Bitmap?>(null, i) { value = runCatching { doc.render(i, (widthPx * 1.6f).toInt()) }.getOrNull() }
                Surface(shadowElevation = 2.dp, color = Color.White, modifier = Modifier.fillMaxWidth().aspectRatio(1f / doc.ratios[i])) {
                    val b = bitmap
                    if (b != null) {
                        Image(b.asImageBitmap(), "Página ${i + 1}", modifier = Modifier.fillMaxSize(), contentScale = ContentScale.FillWidth)
                    } else {
                        Box(contentAlignment = Alignment.Center) { CircularProgressIndicator(Modifier.padding(24.dp)) }
                    }
                }
            }
        }
    }
}

/** Descarga un archivo de la clase con el gestor de descargas de Android (queda en Descargas). */
fun downloadFile(context: Context, url: String, title: String, mime: String) {
    try {
        var name = URLUtil.guessFileName(url, null, mime.ifBlank { null })
        if (title.isNotBlank() && title.contains('.')) name = title
        val request = DownloadManager.Request(Uri.parse(url)).apply {
            if (mime.isNotBlank()) setMimeType(mime)
            setTitle(name)
            setDescription("Impara Academy")
            setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, name)
            } else {
                setDestinationInExternalFilesDir(context, Environment.DIRECTORY_DOWNLOADS, name)
            }
        }
        (context.getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager).enqueue(request)
        Toast.makeText(context, "Descargando $name…", Toast.LENGTH_SHORT).show()
    } catch (e: Exception) {
        Toast.makeText(context, "No se pudo descargar el archivo.", Toast.LENGTH_SHORT).show()
    }
}

