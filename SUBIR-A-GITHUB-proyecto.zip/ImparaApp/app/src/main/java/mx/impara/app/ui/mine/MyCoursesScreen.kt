package mx.impara.app.ui.mine

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.EmojiEvents
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.School
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.PrimaryTabRow
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.pulltorefresh.PullToRefreshBox
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import mx.impara.app.data.ApiException
import mx.impara.app.data.Me
import mx.impara.app.data.Repository
import mx.impara.app.data.WebTarget
import mx.impara.app.ui.LocalActions
import mx.impara.app.ui.LocalRepository
import mx.impara.app.ui.components.CourseProgressCard
import mx.impara.app.ui.components.EmptyState
import mx.impara.app.ui.components.ErrorState
import mx.impara.app.ui.components.MainBottomBar
import mx.impara.app.ui.components.Skeleton
import mx.impara.app.ui.components.UiState
import mx.impara.app.ui.components.Tab as AppTab

class MyCoursesViewModel(private val repo: Repository) : ViewModel() {
    private val _state = MutableStateFlow<UiState<Me>>(UiState.Loading)
    val state = _state.asStateFlow()

    init {
        viewModelScope.launch {
            repo.ready.first { it }
            repo.version.collect { load() }
        }
    }

    fun refresh() {
        viewModelScope.launch { load() }
    }

    private suspend fun load() {
        if (!repo.isLoggedIn) {
            _state.value = UiState.Ready(Me())
            return
        }
        val current = _state.value
        if (current is UiState.Ready) _state.value = current.copy(refreshing = true)
        _state.value = try {
            UiState.Ready(repo.me())
        } catch (e: ApiException) {
            if (current is UiState.Ready && repo.isLoggedIn) current.copy(refreshing = false) else UiState.Error(e.message ?: "")
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MyCoursesScreen() {
    val repo = LocalRepository.current
    val actions = LocalActions.current
    val vm: MyCoursesViewModel = viewModel { MyCoursesViewModel(repo) }
    val state by vm.state.collectAsStateWithLifecycle()
    val session by repo.session.collectAsStateWithLifecycle()
    var tab by rememberSaveable { mutableIntStateOf(0) }

    Scaffold(
        topBar = { TopAppBar(title = { Text("Mis cursos") }) },
        bottomBar = { MainBottomBar(AppTab.Mine, actions::tab) },
    ) { padding ->
        Box(Modifier.fillMaxSize().padding(padding)) {
            if (session == null) {
                EmptyState(
                    Icons.Rounded.Lock,
                    "Inicia sesión",
                    "Entra con tu cuenta de Impara Academy para ver tus cursos y continuar donde te quedaste.",
                    action = "Iniciar sesión",
                    onAction = actions::login,
                )
                return@Box
            }
            when (val s = state) {
                UiState.Loading -> Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    repeat(4) { Skeleton(Modifier.fillMaxWidth().height(110.dp), MaterialTheme.shapes.medium) }
                }
                is UiState.Error -> ErrorState(s.message, vm::refresh)
                is UiState.Ready -> {
                    val all = s.data.courses
                    val done = all.filter { (it.progress ?: 0) >= 100 }
                    val active = all.filter { (it.progress ?: 0) < 100 }
                    Column(Modifier.fillMaxSize()) {
                        PrimaryTabRow(selectedTabIndex = tab) {
                            Tab(selected = tab == 0, onClick = { tab = 0 }, text = { Text("En curso (${active.size})") })
                            Tab(selected = tab == 1, onClick = { tab = 1 }, text = { Text("Completados (${done.size})") })
                        }
                        PullToRefreshBox(isRefreshing = s.refreshing, onRefresh = vm::refresh, modifier = Modifier.fillMaxSize()) {
                            val list = if (tab == 0) active else done
                            if (list.isEmpty()) {
                                LazyColumn(Modifier.fillMaxSize()) {
                                    item {
                                        if (all.isEmpty()) {
                                            EmptyState(
                                                Icons.Rounded.School,
                                                "Aún no tienes cursos",
                                                "Explora el catálogo y empieza hoy. Tus cursos aparecerán aquí.",
                                                action = "Explorar cursos",
                                                onAction = { actions.tab(AppTab.Explore) },
                                            )
                                        } else if (tab == 1) {
                                            EmptyState(
                                                Icons.Rounded.EmojiEvents,
                                                "Tu primer logro te espera",
                                                "Cuando termines un curso aparecerá aquí, listo para tu constancia DC-3.",
                                            )
                                        } else {
                                            EmptyState(
                                                Icons.Rounded.EmojiEvents,
                                                "¡Terminaste todos tus cursos!",
                                                "Sigue creciendo con un curso nuevo.",
                                                action = "Explorar cursos",
                                                onAction = { actions.tab(AppTab.Explore) },
                                            )
                                        }
                                    }
                                }
                            } else {
                                LazyColumn(
                                    Modifier.fillMaxSize(),
                                    contentPadding = PaddingValues(16.dp),
                                    verticalArrangement = Arrangement.spacedBy(12.dp),
                                ) {
                                    items(list, key = { it.id }) { c ->
                                        CourseProgressCard(
                                            c,
                                            onClick = { actions.course(c.id) },
                                            onContinue = { actions.learn(c.id) },
                                            modifier = Modifier.fillMaxWidth(),
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
