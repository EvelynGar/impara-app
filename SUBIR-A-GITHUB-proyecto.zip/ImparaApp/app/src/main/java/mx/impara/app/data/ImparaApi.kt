package mx.impara.app.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.decodeFromString
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.put
import mx.impara.app.BuildConfig
import okhttp3.Cache
import okhttp3.HttpUrl
import okhttp3.HttpUrl.Companion.toHttpUrl
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.File
import java.io.IOException
import java.util.concurrent.TimeUnit

/**
 * Cliente de la API del sitio (namespace impara/v1/app).
 */
class ImparaApi(cacheDir: File, private val tokenProvider: () -> String?) {

    val json = Json {
        ignoreUnknownKeys = true
        coerceInputValues = true
        explicitNulls = false
        isLenient = true
    }

    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .cache(Cache(File(cacheDir, "http"), 10L * 1024 * 1024))
        .addInterceptor { chain ->
            val builder = chain.request().newBuilder()
                .header("Accept", "application/json")
                .header("User-Agent", "ImparaApp/${BuildConfig.VERSION_NAME} (Android)")
            tokenProvider()?.let { builder.header("X-Impara-Token", it) }
            chain.proceed(builder.build())
        }
        .build()

    private val base: HttpUrl = (BuildConfig.BASE_URL + "wp-json/impara/v1/app/").toHttpUrl()

    private fun url(path: String, vararg query: Pair<String, Any?>): HttpUrl {
        val b = base.newBuilder().addPathSegments(path)
        query.forEach { (k, v) -> if (v != null) b.addQueryParameter(k, v.toString()) }
        // Evita respuestas de caché del servidor (cada alumno ve datos distintos).
        b.addQueryParameter("_", (System.currentTimeMillis() / 60000).toString())
        return b.build()
    }

    private suspend fun execute(request: Request): String = withContext(Dispatchers.IO) {
        val response = try {
            client.newCall(request).execute()
        } catch (e: IOException) {
            throw ApiException("No hay conexión. Revisa tu internet e intenta de nuevo.")
        }
        response.use { r ->
            val body = r.body?.string().orEmpty()
            if (!r.isSuccessful) {
                val msg = runCatching { json.decodeFromString(ApiError.serializer(), body).message }
                    .getOrNull()
                    ?.takeIf { it.isNotBlank() }
                    ?: when (r.code) {
                        401, 403 -> "Tu sesión expiró. Vuelve a iniciar sesión."
                        404 -> "No encontramos lo que buscabas."
                        429 -> "Demasiados intentos. Espera unos minutos."
                        else -> "El servidor no respondió (${r.code}). Intenta más tarde."
                    }
                throw ApiException(msg, r.code)
            }
            body
        }
    }

    private suspend inline fun <reified T> get(path: String, vararg query: Pair<String, Any?>): T {
        val body = execute(Request.Builder().url(url(path, *query)).get().build())
        return decode(body)
    }

    private suspend inline fun <reified T> post(path: String, payload: String): T {
        val req = Request.Builder()
            .url(url(path))
            .post(payload.toRequestBody("application/json; charset=utf-8".toMediaType()))
            .build()
        return decode(execute(req))
    }

    private inline fun <reified T> decode(body: String): T = try {
        json.decodeFromString<T>(body)
    } catch (e: Exception) {
        throw ApiException("Recibimos una respuesta inesperada del sitio. Intenta más tarde.")
    }

    suspend fun home(): Home = get("home")

    suspend fun courses(cat: Long = 0, q: String = "", page: Int = 1, perPage: Int = 20): CoursePage =
        get("courses", "cat" to cat.takeIf { it > 0 }, "q" to q.takeIf { it.isNotBlank() }, "page" to page, "per_page" to perPage)

    suspend fun course(id: Long): CourseDetail = get("courses/$id")

    suspend fun bundle(id: Long): BundleDetail = get("bundles/$id")

    suspend fun me(): Me = get("me")

    suspend fun learn(courseId: Long): LearnData = get("learn/$courseId")

    suspend fun adminUsers(q: String): AdminUsers = get("admin/users", "q" to q.takeIf { it.isNotBlank() })

    suspend fun adminUser(id: Long): AdminUserDetail = get("admin/users/$id")

    suspend fun adminCatalog(): AdminCatalog = get("admin/catalog")

    suspend fun adminChange(enroll: Boolean, userId: Long, courseId: Long, bundleId: Long): AdminChange =
        post(if (enroll) "admin/enroll" else "admin/unenroll", buildJsonObject {
            put("user_id", userId)
            put("course_id", courseId)
            put("bundle_id", bundleId)
        }.toString())

    suspend fun complete(courseId: Long, itemId: Long): CompleteResult =
        post("learn/$courseId/complete", buildJsonObject { put("item_id", itemId) }.toString())

    suspend fun notifications(since: Long): NoticeList = get("notifications", "since" to since.takeIf { it > 0 })

    suspend fun login(username: String, password: String, device: String): LoginResponse =
        post("login", buildJsonObject {
            put("username", username)
            put("password", password)
            put("device", device)
        }.toString())

    suspend fun register(name: String, email: String, password: String, device: String): LoginResponse =
        post("register", buildJsonObject {
            put("name", name)
            put("email", email)
            put("password", password)
            put("device", device)
        }.toString())

    suspend fun logout() {
        runCatching { post<Map<String, Boolean>>("logout", "{}") }
    }

    suspend fun webLink(courseId: Long = 0, productId: Long = 0, url: String = ""): WebLink =
        post("web-link", buildJsonObject {
            put("course_id", courseId)
            put("product_id", productId)
            put("url", url)
        }.toString())
}
