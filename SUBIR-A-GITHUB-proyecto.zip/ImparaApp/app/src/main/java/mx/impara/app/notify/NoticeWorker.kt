package mx.impara.app.notify

import android.Manifest
import android.annotation.SuppressLint
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import kotlinx.coroutines.flow.first
import mx.impara.app.ImparaApp
import mx.impara.app.MainActivity
import mx.impara.app.R
import mx.impara.app.data.Notice

/**
 * Revisa cada hora si hay avisos nuevos publicados en el sitio
 * (wp-admin → Avisos app) y los muestra como notificación.
 */
class NoticeWorker(context: Context, params: WorkerParameters) : CoroutineWorker(context, params) {

    override suspend fun doWork(): Result {
        val repo = (applicationContext as ImparaApp).repository
        val store = repo.store
        val last = store.lastNoticeId()
        val items = try {
            repo.api.notifications(since = if (last > 0) last else 0).items
        } catch (e: Exception) {
            return Result.retry()
        }
        val newest = items.maxOfOrNull { it.id } ?: 0L

        // Primera sincronización en este teléfono: no mostrar avisos viejos.
        if (last < 0) {
            store.setLastNoticeId(newest)
            return Result.success()
        }
        if (newest <= last) return Result.success()
        store.setLastNoticeId(newest)

        if (!store.notificationsEnabled.first() || !canNotify(applicationContext)) return Result.success()
        items.filter { it.id > last }.sortedBy { it.id }.takeLast(3).forEach { show(applicationContext, it) }
        return Result.success()
    }

    companion object {
        const val CHANNEL_ID = "avisos"
        const val WORK_NAME = "impara_avisos"

        fun canNotify(context: Context): Boolean {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
                ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
            ) return false
            return NotificationManagerCompat.from(context).areNotificationsEnabled()
        }

        @SuppressLint("MissingPermission")
        fun show(context: Context, notice: Notice) {
            val intent = Intent(context, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
                if (notice.url.isNotBlank()) putExtra(MainActivity.EXTRA_URL, notice.url)
                putExtra(MainActivity.EXTRA_TITLE, notice.title)
            }
            val pending = PendingIntent.getActivity(
                context,
                notice.id.toInt(),
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
            )
            val notification = NotificationCompat.Builder(context, CHANNEL_ID)
                .setSmallIcon(R.drawable.ic_notification)
                .setColor(ContextCompat.getColor(context, R.color.impara_purple))
                .setContentTitle(notice.title)
                .setContentText(notice.body)
                .setStyle(NotificationCompat.BigTextStyle().bigText(notice.body))
                .setAutoCancel(true)
                .setContentIntent(pending)
                .build()
            try {
                NotificationManagerCompat.from(context).notify(notice.id.toInt(), notification)
            } catch (_: SecurityException) {
                // Permiso retirado por el alumno: no se muestra.
            }
        }
    }
}
