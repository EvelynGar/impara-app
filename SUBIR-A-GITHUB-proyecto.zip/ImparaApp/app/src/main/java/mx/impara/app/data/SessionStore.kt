package mx.impara.app.data

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.serialization.json.Json

private val Context.dataStore by preferencesDataStore(name = "impara_session")

/** Datos guardados en el teléfono: sesión, último aviso visto y preferencias. */
class SessionStore(private val context: Context, private val json: Json) {

    private val kToken = stringPreferencesKey("token")
    private val kUser = stringPreferencesKey("user")
    private val kLastNotice = longPreferencesKey("last_notice")
    private val kNotify = booleanPreferencesKey("notify")

    data class Session(val token: String, val user: User)

    val session = context.dataStore.data.map { p ->
        val token = p[kToken]
        val user = p[kUser]?.let { runCatching { json.decodeFromString(User.serializer(), it) }.getOrNull() }
        if (token.isNullOrBlank() || user == null) null else Session(token, user)
    }

    val notificationsEnabled = context.dataStore.data.map { it[kNotify] ?: true }

    suspend fun current(): Session? = session.first()

    suspend fun save(token: String, user: User) {
        context.dataStore.edit {
            it[kToken] = token
            it[kUser] = json.encodeToString(User.serializer(), user)
        }
    }

    suspend fun updateUser(user: User) {
        context.dataStore.edit { it[kUser] = json.encodeToString(User.serializer(), user) }
    }

    suspend fun clear() {
        context.dataStore.edit {
            it.remove(kToken)
            it.remove(kUser)
        }
    }

    /** -1 = todavía no se sincronizan los avisos en este teléfono. */
    suspend fun lastNoticeId(): Long = context.dataStore.data.first()[kLastNotice] ?: -1L

    suspend fun setLastNoticeId(id: Long) {
        context.dataStore.edit { it[kLastNotice] = id }
    }

    suspend fun setNotificationsEnabled(enabled: Boolean) {
        context.dataStore.edit { it[kNotify] = enabled }
    }
}
