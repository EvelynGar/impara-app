package mx.impara.app

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import androidx.work.Constraints
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.NetworkType
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import mx.impara.app.data.Repository
import mx.impara.app.notify.NoticeWorker
import java.util.concurrent.TimeUnit

class ImparaApp : Application() {

    lateinit var repository: Repository
        private set

    override fun onCreate() {
        super.onCreate()
        repository = Repository(this)
        createChannel()
        scheduleNotices()
    }

    private fun createChannel() {
        val channel = NotificationChannel(
            NoticeWorker.CHANNEL_ID,
            getString(R.string.channel_notices),
            NotificationManager.IMPORTANCE_DEFAULT,
        ).apply { description = getString(R.string.channel_notices_desc) }
        getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
    }

    private fun scheduleNotices() {
        val request = PeriodicWorkRequestBuilder<NoticeWorker>(1, TimeUnit.HOURS)
            .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build())
            .build()
        WorkManager.getInstance(this).enqueueUniquePeriodicWork(
            NoticeWorker.WORK_NAME,
            ExistingPeriodicWorkPolicy.KEEP,
            request,
        )
    }
}
