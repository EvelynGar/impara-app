package mx.impara.app

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import mx.impara.app.ui.AppNav
import mx.impara.app.ui.theme.ImparaTheme

class MainActivity : ComponentActivity() {

    /** Página pendiente de abrir (url, título) que llega de una notificación o un enlace. */
    private var pending by mutableStateOf<Pair<String, String>?>(null)

    override fun onCreate(savedInstanceState: Bundle?) {
        val splash = installSplashScreen()
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val repo = (application as ImparaApp).repository
        // Mantener la pantalla de inicio hasta leer la sesión guardada (unos milisegundos).
        splash.setKeepOnScreenCondition { !repo.ready.value }

        if (savedInstanceState == null) handle(intent)

        setContent {
            ImparaTheme {
                AppNav(repo = repo, pendingUrl = pending, onPendingHandled = { pending = null })
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handle(intent)
    }

    private fun handle(intent: Intent?) {
        intent ?: return
        val url = intent.getStringExtra(EXTRA_URL) ?: intent.data?.toString()
        if (!url.isNullOrBlank()) {
            pending = url to (intent.getStringExtra(EXTRA_TITLE) ?: "Impara Academy")
        }
    }

    companion object {
        const val EXTRA_URL = "open_url"
        const val EXTRA_TITLE = "open_title"
    }
}
