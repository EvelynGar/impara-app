package mx.impara.app.ui.login

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.ErrorOutline
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.Mail
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material.icons.rounded.School
import androidx.compose.material.icons.rounded.Visibility
import androidx.compose.material.icons.rounded.VisibilityOff
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.SegmentedButton
import androidx.compose.material3.SegmentedButtonDefaults
import androidx.compose.material3.SingleChoiceSegmentedButtonRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch
import mx.impara.app.data.ApiException
import mx.impara.app.data.Repository
import mx.impara.app.ui.LocalActions
import mx.impara.app.ui.LocalRepository
import mx.impara.app.ui.theme.ImparaPurple
import mx.impara.app.ui.theme.ImparaPurpleDeep

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LoginScreen() {
    val repo = LocalRepository.current
    val actions = LocalActions.current
    val scope = rememberCoroutineScope()
    val focus = LocalFocusManager.current

    var register by rememberSaveable { mutableStateOf(false) }
    var name by rememberSaveable { mutableStateOf("") }
    var email by rememberSaveable { mutableStateOf("") }
    var password by rememberSaveable { mutableStateOf("") }
    var terms by rememberSaveable { mutableStateOf(false) }
    var showPass by rememberSaveable { mutableStateOf(false) }
    var busy by rememberSaveable { mutableStateOf(false) }
    var error by rememberSaveable { mutableStateOf<String?>(null) }

    fun submit() {
        focus.clearFocus()
        error = when {
            register && name.isBlank() -> "Escribe tu nombre."
            email.isBlank() -> if (register) "Escribe tu correo electrónico." else "Escribe tu correo o usuario."
            register && !android.util.Patterns.EMAIL_ADDRESS.matcher(email.trim()).matches() -> "Escribe un correo electrónico válido."
            password.isEmpty() -> "Escribe tu contraseña."
            register && password.length < 8 -> "Tu contraseña debe tener al menos 8 caracteres."
            register && !terms -> "Acepta el aviso de privacidad para crear tu cuenta."
            else -> null
        }
        if (error != null) return
        busy = true
        scope.launch {
            try {
                if (register) repo.register(name, email, password) else repo.login(email, password)
                busy = false
                actions.back()
            } catch (e: ApiException) {
                busy = false
                error = e.message
            }
        }
    }

    Column(
        Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.surface)
            .imePadding()
            .navigationBarsPadding()
            .verticalScroll(rememberScrollState()),
    ) {
        Box(
            Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(bottomStart = 32.dp, bottomEnd = 32.dp))
                .background(Brush.linearGradient(listOf(ImparaPurple, ImparaPurpleDeep)))
                .statusBarsPadding()
                .padding(start = 8.dp, end = 24.dp, top = 4.dp, bottom = 28.dp),
        ) {
            Column {
                IconButton(onClick = { actions.back() }) { Icon(Icons.Rounded.Close, "Cerrar", tint = Color.White) }
                Column(Modifier.padding(start = 16.dp)) {
                    Box(
                        Modifier.size(56.dp).clip(CircleShape).background(Color.White.copy(alpha = .16f)),
                        contentAlignment = Alignment.Center,
                    ) { Icon(Icons.Rounded.School, null, tint = Color.White, modifier = Modifier.size(30.dp)) }
                    Spacer(Modifier.height(16.dp))
                    Text(
                        if (register) "Crea tu cuenta" else "¡Hola de nuevo!",
                        style = MaterialTheme.typography.headlineMedium,
                        color = Color.White,
                    )
                    Text(
                        if (register) "Regístrate gratis en menos de un minuto." else "Inicia sesión para continuar con tus cursos.",
                        style = MaterialTheme.typography.bodyLarge,
                        color = Color.White.copy(alpha = .85f),
                    )
                }
            }
        }

        Column(Modifier.padding(24.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            SingleChoiceSegmentedButtonRow(Modifier.fillMaxWidth()) {
                SegmentedButton(
                    selected = !register,
                    onClick = { register = false; error = null },
                    shape = SegmentedButtonDefaults.itemShape(0, 2),
                ) { Text("Iniciar sesión") }
                SegmentedButton(
                    selected = register,
                    onClick = { register = true; error = null },
                    shape = SegmentedButtonDefaults.itemShape(1, 2),
                ) { Text("Crear cuenta") }
            }

            AnimatedVisibility(register) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Nombre") },
                    leadingIcon = { Icon(Icons.Rounded.Person, null) },
                    singleLine = true,
                    shape = MaterialTheme.shapes.medium,
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next),
                    modifier = Modifier.fillMaxWidth(),
                )
            }
            OutlinedTextField(
                value = email,
                onValueChange = { email = it },
                label = { Text(if (register) "Correo electrónico" else "Correo o usuario") },
                leadingIcon = { Icon(Icons.Rounded.Mail, null) },
                singleLine = true,
                shape = MaterialTheme.shapes.medium,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email, imeAction = ImeAction.Next),
                modifier = Modifier.fillMaxWidth(),
            )
            OutlinedTextField(
                value = password,
                onValueChange = { password = it },
                label = { Text(if (register) "Crea una contraseña" else "Contraseña") },
                leadingIcon = { Icon(Icons.Rounded.Lock, null) },
                trailingIcon = {
                    IconButton(onClick = { showPass = !showPass }) {
                        Icon(
                            if (showPass) Icons.Rounded.VisibilityOff else Icons.Rounded.Visibility,
                            if (showPass) "Ocultar contraseña" else "Mostrar contraseña",
                        )
                    }
                },
                supportingText = if (register) {
                    { Text("Mínimo 8 caracteres") }
                } else {
                    null
                },
                visualTransformation = if (showPass) VisualTransformation.None else PasswordVisualTransformation(),
                singleLine = true,
                shape = MaterialTheme.shapes.medium,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password, imeAction = ImeAction.Done),
                keyboardActions = KeyboardActions(onDone = { submit() }),
                modifier = Modifier.fillMaxWidth(),
            )

            if (register) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = terms, onCheckedChange = { terms = it })
                    Text(
                        "Acepto el aviso de privacidad y recibir información de mis cursos.",
                        style = MaterialTheme.typography.bodySmall,
                    )
                }
            } else {
                TextButton(
                    onClick = { actions.web("Recuperar contraseña", Repository.LOST_PASSWORD_URL) },
                    modifier = Modifier.align(Alignment.End),
                ) { Text("¿Olvidaste tu contraseña?") }
            }

            AnimatedVisibility(error != null) {
                Surface(color = MaterialTheme.colorScheme.errorContainer, shape = MaterialTheme.shapes.medium) {
                    Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Rounded.ErrorOutline, null, tint = MaterialTheme.colorScheme.onErrorContainer)
                        Spacer(Modifier.width(10.dp))
                        Text(error ?: "", color = MaterialTheme.colorScheme.onErrorContainer, style = MaterialTheme.typography.bodyMedium)
                    }
                }
            }

            Button(
                onClick = { submit() },
                enabled = !busy,
                modifier = Modifier.fillMaxWidth().height(54.dp),
            ) {
                if (busy) {
                    CircularProgressIndicator(Modifier.size(22.dp), strokeWidth = 2.5.dp, color = MaterialTheme.colorScheme.onPrimary)
                } else {
                    Text(if (register) "Crear mi cuenta" else "Iniciar sesión")
                }
            }

            Text(
                "Usa el mismo correo y contraseña de impara-academy.com.mx.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth(),
            )
        }
    }
}
