package mx.impara.app.data

import android.content.Context
import android.os.Build
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking
import mx.impara.app.BuildConfig

/** Lo que se abre dentro de la vista web de la app. */
data class WebTarget(
    val title: String,
    val url: String = "",
    val courseId: Long = 0,
    val productId: Long = 0,
)

class Repository(context: Context) {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    @Volatile private var token: String? = null
    @Volatile private var loaded = false

    val api: ImparaApi = ImparaApi(context.cacheDir) {
        if (!loaded) runBlocking { store.current()?.token } else token
    }
    val store = SessionStore(context.applicationContext, api.json)

    private val _session = MutableStateFlow<SessionStore.Session?>(null)
    val session: StateFlow<SessionStore.Session?> = _session.asStateFlow()

    private val _ready = MutableStateFlow(false)
    /** true cuando ya se leyó la sesión guardada en el teléfono. */
    val ready: StateFlow<Boolean> = _ready.asStateFlow()

    /** Cambia cada vez que el alumno compra, inicia o cierra sesión: las pantallas se recargan. */
    private val _version = MutableStateFlow(0)
    val version: StateFlow<Int> = _version.asStateFlow()

    init {
        scope.launch {
            store.session.collect { s ->
                token = s?.token
                loaded = true
                _session.value = s
                _ready.value = true
            }
        }
    }

    val isLoggedIn: Boolean get() = _session.value != null

    fun invalidate() {
        _version.value = _version.value + 1
    }

    suspend fun home() = api.home()
    suspend fun courses(cat: Long, q: String, page: Int) = api.courses(cat = cat, q = q, page = page)
    suspend fun course(id: Long) = api.course(id)
    suspend fun bundle(id: Long) = api.bundle(id)

    suspend fun me(): Me = try {
        api.me().also { m -> m.user?.let { store.updateUser(it) } }
    } catch (e: ApiException) {
        if (e.status == 401) {
            store.clear()
            invalidate()
        }
        throw e
    }

    suspend fun login(username: String, password: String) {
        val device = "${Build.MANUFACTURER} ${Build.MODEL}".trim()
        val res = api.login(username.trim(), password, device)
        val user = res.user ?: throw ApiException("No pudimos iniciar sesión. Intenta de nuevo.")
        token = res.token
        store.save(res.token, user)
        invalidate()
    }

    suspend fun register(name: String, email: String, password: String) {
        val device = "${Build.MANUFACTURER} ${Build.MODEL}".trim()
        val res = api.register(name.trim(), email.trim(), password, device)
        val user = res.user ?: throw ApiException("No pudimos crear tu cuenta. Intenta de nuevo.")
        token = res.token
        store.save(res.token, user)
        invalidate()
    }

    suspend fun logout() {
        api.logout()
        token = null
        store.clear()
        invalidate()
    }

    /**
     * Devuelve la URL que se abre en la vista web. Con sesión iniciada, el sitio
     * entrega un enlace de un solo uso que abre la web ya con la cuenta del alumno.
     */
    suspend fun resolveWebUrl(t: WebTarget): String {
        if (isLoggedIn) {
            runCatching { api.webLink(t.courseId, t.productId, t.url).url }
                .getOrNull()
                ?.takeIf { it.isNotBlank() }
                ?.let { return it }
        }
        return when {
            t.productId > 0 -> "${BuildConfig.BASE_URL}cart/?add-to-cart=${t.productId}&impara_app_checkout=1"
            t.url.isNotBlank() -> t.url
            else -> BuildConfig.BASE_URL
        }
    }

    companion object {
        val SITE = BuildConfig.BASE_URL
        val LOGIN_URL = BuildConfig.BASE_URL + "login/"
        val LOST_PASSWORD_URL = BuildConfig.BASE_URL + "lost-password/"
    }
}
