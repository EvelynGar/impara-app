package mx.impara.app.ui.home

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AllInclusive
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.SupportAgent
import androidx.compose.material.icons.rounded.WorkspacePremium
import androidx.compose.material.icons.rounded.Devices
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.pulltorefresh.PullToRefreshBox
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import mx.impara.app.data.ApiException
import mx.impara.app.data.Home
import mx.impara.app.data.Repository
import mx.impara.app.data.WebTarget
import mx.impara.app.ui.LocalActions
import mx.impara.app.ui.LocalRepository
import mx.impara.app.ui.components.BundleCard
import mx.impara.app.ui.components.CourseCard
import mx.impara.app.ui.components.CourseProgressCard
import mx.impara.app.ui.components.ErrorState
import mx.impara.app.ui.components.MainBottomBar
import mx.impara.app.ui.components.NetImage
import mx.impara.app.ui.components.SectionTitle
import mx.impara.app.ui.components.Skeleton
import mx.impara.app.ui.components.Tab
import mx.impara.app.ui.components.UiState
import mx.impara.app.ui.components.number
import mx.impara.app.ui.theme.ImparaOrange
import mx.impara.app.ui.theme.ImparaPurple
import mx.impara.app.ui.theme.ImparaPurpleDeep

/** Se pide el permiso de notificaciones solo una vez por sesión de la app. */
private var askedNotifications = false

class HomeViewModel(private val repo: Repository) : ViewModel() {
    private val _state = MutableStateFlow<UiState<Home>>(UiState.Loading)
    val state = _state.asStateFlow()

    init {
        viewModelScope.launch {
            repo.ready.first { it }
            repo.version.collect { load() }
        }
    }

    fun refresh() {
        viewModelScope.launch { load() }
    }

    private suspend fun load() {
        val current = _state.value
        if (current is UiState.Ready) _state.value = current.copy(refreshing = true)
        _state.value = try {
            UiState.Ready(repo.home())
        } catch (e: ApiException) {
            if (current is UiState.Ready) current.copy(refreshing = false) else UiState.Error(e.message ?: "")
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen() {
    val repo = LocalRepository.current
    val actions = LocalActions.current
    val vm: HomeViewModel = viewModel { HomeViewModel(repo) }
    val state by vm.state.collectAsStateWithLifecycle()
    val session by repo.session.collectAsStateWithLifecycle()

    // Pedir permiso de notificaciones (Android 13+) una sola vez al abrir.
    val permission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU && !askedNotifications) {
            askedNotifications = true
            permission.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    Scaffold(
        bottomBar = { MainBottomBar(Tab.Home, actions::tab) },
    ) { padding ->
        when (val s = state) {
            UiState.Loading -> HomeSkeleton(Modifier.padding(padding))
            is UiState.Error -> ErrorState(s.message, vm::refresh, Modifier.padding(padding))
            is UiState.Ready -> PullToRefreshBox(
                isRefreshing = s.refreshing,
                onRefresh = vm::refresh,
                modifier = Modifier.fillMaxSize().padding(bottom = padding.calculateBottomPadding()),
            ) {
                HomeContent(s.data, session?.user?.name)
            }
        }
    }
}

@Composable
private fun HomeContent(home: Home, userName: String?) {
    val actions = LocalActions.current
    val context = LocalContext.current
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 24.dp)) {
        item { Header(home, userName) }

        if (home.`continue`.isNotEmpty()) {
            item { SectionTitle("Continúa aprendiendo", action = "Ver todos") { actions.tab(Tab.Mine) } }
            item {
                LazyRow(contentPadding = PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    items(home.`continue`, key = { it.id }) { c ->
                        CourseProgressCard(
                            c,
                            onClick = { actions.course(c.id) },
                            onContinue = { actions.web(WebTarget(title = c.title, courseId = c.id)) },
                            modifier = Modifier.width(310.dp),
                        )
                    }
                }
            }
        }

        if (home.bundles.isNotEmpty()) {
            item { SectionTitle("Diplomados y paquetes") }
            item {
                Text(
                    "Todos los cursos de una ruta por un solo pago.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(horizontal = 16.dp).padding(bottom = 8.dp),
                )
            }
            item {
                LazyRow(contentPadding = PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    items(home.bundles, key = { it.id }) { b -> BundleCard(b, onClick = { actions.bundle(b.id) }) }
                }
            }
        }

        if (home.categories.isNotEmpty()) {
            item { SectionTitle("Categorías", action = "Explorar") { actions.tab(Tab.Explore) } }
            item {
                LazyRow(contentPadding = PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    items(home.categories, key = { it.id }) { cat ->
                        Column(
                            Modifier
                                .width(96.dp)
                                .clip(MaterialTheme.shapes.medium)
                                .clickable { actions.explore(cat.id) }
                                .padding(vertical = 6.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                        ) {
                            NetImage(cat.image, Modifier.size(72.dp).clip(CircleShape))
                            Spacer(Modifier.height(8.dp))
                            Text(cat.name, style = MaterialTheme.typography.labelLarge, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(
                                "${cat.count} cursos",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                            )
                        }
                    }
                }
            }
        }

        if (home.featured.isNotEmpty()) {
            item { SectionTitle("Cursos nuevos", action = "Ver todos") { actions.tab(Tab.Explore) } }
            item {
                LazyRow(contentPadding = PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    items(home.featured, key = { it.id }) { c ->
                        CourseCard(c, onClick = { actions.course(c.id) }, modifier = Modifier.width(210.dp))
                    }
                }
            }
        }

        item { SectionTitle("¿Por qué Impara?") }
        item {
            Column(Modifier.padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Benefit(Icons.Rounded.WorkspacePremium, "Constancia DC-3 y diploma", "Avalada por la STPS al concluir cada curso.")
                Benefit(Icons.Rounded.AllInclusive, "Acceso sin fecha de expiración", "Estudia a tu ritmo, 100% en línea.")
                Benefit(Icons.Rounded.Devices, "Desde cualquier dispositivo", "Celular, tablet o computadora.")
            }
        }
        item {
            Card(
                Modifier.fillMaxWidth().padding(16.dp),
                shape = MaterialTheme.shapes.large,
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.tertiaryContainer),
            ) {
                Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Rounded.SupportAgent, null, Modifier.size(36.dp), tint = MaterialTheme.colorScheme.onTertiaryContainer)
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text("¿Tienes dudas?", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.onTertiaryContainer)
                        Text(
                            "Te ayudamos por WhatsApp a elegir tu curso.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onTertiaryContainer,
                        )
                    }
                    FilledTonalButton(onClick = {
                        val i = Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/${home.whatsapp}?text=" + Uri.encode("Hola, vengo de la app de Impara Academy y tengo una duda.")))
                        runCatching { context.startActivity(i) }
                    }) { Text("Escribir") }
                }
            }
        }
    }
}

@Composable
private fun Header(home: Home, userName: String?) {
    val actions = LocalActions.current
    val first = userName?.trim()?.substringBefore(' ')?.takeIf { it.isNotBlank() }
    Box(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(bottomStart = 28.dp, bottomEnd = 28.dp))
            .background(Brush.linearGradient(listOf(ImparaPurple, ImparaPurpleDeep)))
            .statusBarsPadding()
            .padding(horizontal = 20.dp, vertical = 16.dp),
    ) {
        Column {
            Text(
                "IMPARA ACADEMY",
                style = MaterialTheme.typography.labelMedium,
                color = Color.White.copy(alpha = .7f),
                letterSpacing = MaterialTheme.typography.labelMedium.letterSpacing * 3,
            )
            Spacer(Modifier.height(12.dp))
            Text(
                if (first != null) "Hola, $first" else "Aprende con Impara",
                style = MaterialTheme.typography.headlineMedium,
                color = Color.White,
            )
            Text(
                "¿Qué quieres aprender hoy?",
                style = MaterialTheme.typography.bodyLarge,
                color = Color.White.copy(alpha = .85f),
            )
            Spacer(Modifier.height(16.dp))
            Surface(
                onClick = { actions.explore(search = true) },
                shape = CircleShape,
                color = Color.White,
                contentColor = Color(0xFF4C444F),
                modifier = Modifier.fillMaxWidth().height(52.dp),
            ) {
                Row(Modifier.padding(horizontal = 18.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Rounded.Search, null)
                    Spacer(Modifier.width(10.dp))
                    Text("Busca SAP, Excel, logística…", style = MaterialTheme.typography.bodyLarge)
                }
            }
            if (home.stats.courses > 0) {
                Spacer(Modifier.height(16.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Stat("+${number(home.stats.students)}", "alumnos", Modifier.weight(1f))
                    Stat(number(home.stats.courses), "cursos", Modifier.weight(1f))
                    Stat("+${number(home.stats.lessons)}", "clases", Modifier.weight(1f))
                }
            }
        }
    }
}

@Composable
private fun Stat(value: String, label: String, modifier: Modifier) {
    Column(
        modifier
            .clip(MaterialTheme.shapes.medium)
            .background(Color.White.copy(alpha = .12f))
            .padding(vertical = 10.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text(value, style = MaterialTheme.typography.titleMedium, color = Color.White, fontWeight = FontWeight.Bold)
        Text(label, style = MaterialTheme.typography.labelSmall, color = Color.White.copy(alpha = .8f))
    }
}

@Composable
private fun Benefit(icon: ImageVector, title: String, text: String) {
    Row(
        Modifier
            .fillMaxWidth()
            .clip(MaterialTheme.shapes.medium)
            .background(MaterialTheme.colorScheme.surfaceContainerLow)
            .padding(14.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(
            Modifier.size(42.dp).clip(CircleShape).background(ImparaOrange.copy(alpha = .15f)),
            contentAlignment = Alignment.Center,
        ) { Icon(icon, null, tint = ImparaOrange) }
        Spacer(Modifier.width(12.dp))
        Column {
            Text(title, style = MaterialTheme.typography.titleSmall)
            Text(text, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun HomeSkeleton(modifier: Modifier = Modifier) {
    Column(modifier.fillMaxSize()) {
        Box(
            Modifier
                .fillMaxWidth()
                .height(260.dp)
                .clip(RoundedCornerShape(bottomStart = 28.dp, bottomEnd = 28.dp))
                .background(Brush.linearGradient(listOf(ImparaPurple, ImparaPurpleDeep))),
        )
        Spacer(Modifier.height(20.dp))
        Skeleton(Modifier.padding(horizontal = 16.dp).width(200.dp).height(24.dp))
        Spacer(Modifier.height(12.dp))
        Row(Modifier.padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Skeleton(Modifier.width(300.dp).height(170.dp), MaterialTheme.shapes.large)
            Skeleton(Modifier.width(300.dp).height(170.dp), MaterialTheme.shapes.large)
        }
        Spacer(Modifier.height(20.dp))
        Skeleton(Modifier.padding(horizontal = 16.dp).width(160.dp).height(24.dp))
        Spacer(Modifier.height(12.dp))
        Row(Modifier.padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            repeat(4) { Skeleton(Modifier.size(72.dp), CircleShape) }
        }
    }
}
